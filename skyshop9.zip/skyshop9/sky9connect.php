<?php

$con=mysqli_connect("localhost","root","","skyphp");

if(!$con){
    // die("connection error ".mysqli_errno($con));
    echo "Conection error";

}

?>