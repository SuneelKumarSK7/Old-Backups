<?php
include 'sky9connect.php';


$fnameerr = $lnameerr = $emailerr = $passerr = "";
$IFirstN = $ILastN = $IEmail = $IPsword = "";
$Err = "";

$requirement = true;

if (isset($_POST['submit'])) {

    if (empty($_POST['fname'])) {
        $fnameerr = "First Name is required";
        $requirement = false;
    } else {
        $fname = ucwords($_POST['fname']);
        $IFirstN = $fname;

        if (!preg_match("/^[a-zA-Z-' ]*$/", $fname)) {
            $fnameerr = "Only letters allowed";
            $requirement = false;
        } elseif (strlen($fname) > 10) {
            $fnameerr = "Name length allowd only less than 12 charector";
            $requirement = false;
        } elseif (strlen($fname) < 3) {
            $fnameerr = "Name length aloud greater than 2 charctor";
            $requirement = false;
        }
    }

    // Last name validation
    if (empty($_POST['lname'])) {
        $lnameerr = "Last Name is required";
        $requirement = false;
    } else {
        $lname = ucwords($_POST['lname']);
        $ILastN = $lname;

        if (!preg_match("/^[a-zA-Z-' ]*$/", $lname)) {
            $lnameerr = "Only letters allowed";
            $requirement = false;
        } elseif (strlen($lname) > 12) {
            $lnameerr = "Name length allowd only less than 12 charector";
            $requirement = false;
        } elseif (strlen($lname) < 3) {
            $lnameerr = "Name length allowd greater than 2 charector";
            $requirement = false;
        }
    }

    // Email validation
    if (empty($_POST['email'])) {
        $emailerr = "Email is required";
        $requirement = false;
    } else {
        $email = $_POST['email'];
        $IEmail = $email;

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $emailerr = "Invalid email format";
            $requirement = false;
        }
    }

    // Password validation
    // {8,10}$
    if (empty($_POST['pass'])) {
        $passerr = "Password is required";
        $requirement = false;
    } else {
        $pass = $_POST['pass'];
        $IPsword = $pass;

        if (!preg_match("^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]^", $pass)) {
            $passerr = "At least one upper, lower case, number, special charector ";
            $requirement = false;
        } elseif (strlen($pass) > 10) {
            $passerr = "Password length allowd only less than 10 charector ";
            $requirement = false;
        } elseif (strlen($pass) < 4) {
            $passerr = "Password allowd atleast 4 charector";
            $requirement = false;
        }
    }

    // $fname || $lname || $email || $pass
    if (empty($fname) || empty($lname) || empty($email) || empty($pass)) {
        $Err = "Please fill all requirement";
        $requirement = false;
    } elseif ($fname && $lname && $email && $pass) {

        // $Emailma = "SELECT * FROM webadmintable WHERE Email='$email'";
        // $Passma = "SELECT * FROM webadmintable WHERE Password='$pass'";

        $Emailma = "SELECT * FROM webadmintable WHERE Email=?";
        $Passma = "SELECT * FROM webadmintable WHERE Password=?";

        // $query2 = mysqli_query($con, $Emailma);
        // $query3 = mysqli_query($con, $Passma);

        $query2 = mysqli_prepare($con, $Emailma);
        $query3 = mysqli_prepare($con, $Passma);

        // $row2 = mysqli_fetch_array($query2);
        // $row3 = mysqli_fetch_array($query3);

        mysqli_stmt_bind_param($query2,"s",$email);
        mysqli_stmt_bind_param($query3,"s",$pass);
        
        mysqli_stmt_execute($query2);
        $result2=mysqli_stmt_get_result($query2);

        mysqli_stmt_execute($query3);
        $result3=mysqli_stmt_get_result($query3);

        // if ($row2) {
        //     $emailerr = "Email is already exist";
        //     if ($row3) {
        //         $passerr = "Password is already exist";
        //     }
        // } elseif ($row3) {
        //     $passerr = "Password is already exist";
        // } elseif ($requirement) {
        //     $sql = "SELECT COUNT(*) AS rowCount FROM webadmintable";
        //     $result = mysqli_query($con, $sql);

        //     if($result){
        //         $rowB=mysqli_fetch_assoc($result);
        //         $rowCount = $rowB['rowCount'];

        //         if ($rowCount <= 1) {
        //             $sql2 = "INSERT INTO webadmintable(First_Name,Last_Name,Email,Password) VALUES ('$fname','$lname','$email','$pass')";
        //             $query = mysqli_query($con, $sql2);
        //             if ($query) {
        //                 $IFirstN = $ILastN = $IEmail = $IPsword = "";
        //                 echo "data inserted successful";
        //                 header('location:sky10EcommerceAdminLogin.php');
        //             } else {
        //                 $Err = "data not inserted successful";
        //             }
        //         } else {
        //             $Err = "Unable to insert data. Maximum limit reached.";
        //         }
        //     }else {
        //         // If the query fails, handle the error
        //         echo "Error: " . mysqli_error($conn);
        //     }

        // }

        if ($row2=mysqli_num_rows($result2)>0) {
            $emailerr = "Email is already exist";
            if ($row3=mysqli_num_rows($result3)>0) {
                $passerr = "Password is already exist";
            }
        } elseif ($row3=mysqli_num_rows($result3)>0) {
            $passerr = "Password is already exist";
        } elseif ($requirement) {
            $sql = "SELECT COUNT(*) AS rowCount FROM webadmintable";
            $result = mysqli_query($con, $sql);

            if($result){
                $rowB=mysqli_fetch_assoc($result);
                $rowCount = $rowB['rowCount'];

                if ($rowCount <= 1) {
                    // $hashed_pass=password_hash($pass,PASSWORD_DEFAULT);

                    $sql2 = "INSERT INTO webadmintable(First_Name,Last_Name,Email,Password) VALUES ('$fname','$lname','$email','$pass')";
                    $query = mysqli_query($con, $sql2);
                    if ($query) {
                        $IFirstN = $ILastN = $IEmail = $IPsword = "";
                        echo "data inserted successful";
                        header('location:sky10EcommerceAdminLogin.php');
                    } else {
                        $Err = "data not inserted successful";
                    }
                } else {
                    $Err = "Unable to insert data. Maximum limit reached.";
                }
            }else {
                // If the query fails, handle the error
                echo "Error: " . mysqli_error($conn);
            }

        }
    }
}

?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Registration</title>
    <link rel="stylesheet" href="sky10EcommerceAdmin.css">
</head>

<body>
    <div class="reg">
        <div class="form-con">
            <form action="" method="POST">
                <h1 class="register-text">Admin Registration</h1>
                <span class="err errTop"><?php echo $Err;   ?></span>

                <input class="inp inp-A" type="text" name="fname" placeholder="Enter your first name" value="<?php echo $IFirstN;   ?>">
                <span class="err errA"><?php echo $fnameerr;   ?></span>

                <input class="inp inp-B" type="text" name="lname" placeholder="Enter your last name" value="<?php echo $ILastN;   ?>">
                <span class="err errB"><?php echo $lnameerr;   ?></span>

                <input class="inp inp-C" type="text" name="email" placeholder="Enter your email" value="<?php echo $IEmail;   ?>">
                <span class="err errC"><?php echo $emailerr;   ?></span>

                <input class="inp inp-D" type="text" name="pass" placeholder="Password" value="<?php echo $IPsword;   ?>">
                <span class="err errD"><?php echo $passerr;   ?></span>

                <input class="btn" name="submit" type="submit" value="SUBMIT">
            </form>
        </div>

        <div class="already-register">
            <p>Already have registered <a href="sky10EcommerceAdminLogin.php">click here</a>
            </p>
        </div>
    </div>



    <script type="text/javascript" src="jquery.min.js"></script>


    <script>
        $('.inp-A').on('keyup', function() {
            var ii = $(this).val()
            // console.log(ii)
            $('.errA').html("")
            $('.errTop').html("")

        })

        $('.inp-B').on('keyup', function() {
            var ii = $(this).val()
            // console.log(ii)
            $('.errB').html("")
            $('.errTop').html("")
        })

        $('.inp-C').on('keyup', function() {
            var ii = $(this).val()
            // console.log(ii)
            $('.errC').html("")
            $('.errTop').html("")
        })

        $('.inp-D').on('keyup', function() {
            var ii = $(this).val()
            // console.log(ii)
            $('.errD').html("")
            $('.errTop').html("")
        })
    </script>


</body>

</html>










<!-- $sql = "SELECT * FROM webadmintable WHERE Email=? AND Password=?"; -->


        $query = mysqli_prepare($con, $sql);
        mysqli_stmt_bind_param($query, "ss", $email, $pass);
        mysqli_stmt_execute($query);

        // $row=mysqli_fetch_array($query);
    
        if ($query) {
            if ($row = mysqli_stmt_get_result($query)) {
                if(mysqli_num_rows($row)>0){
                    // $Err = "login success";
                    // if($row2=mysqli_fetch_assoc($query)){

                        $IEmail = $IPassword = "";
                        $_SESSION['userLogin'] = $row['First_Name'];
                        $_SESSION['userLName'] = $row['Last_Name'];
                        $_SESSION['userEmail'] = $row['Email'];
                        $_SESSION['userPassword'] = $row['Password'];
    
                        if (strcmp($_SESSION['userPassword'], $pass) === 0) {
                            // Passwords match
                            echo $_SESSION['userLogin'];
                            header('location:sky10EcommerceAdminDashboard.php');
                        } else {
                            // Passwords do not match
                            $Err = "Invalid password";
                            $requirement = false;
                        }
                    // }


                }else{
                    $Err = "Email and password invalid something went wrong";
                }

    
               
            } else {
                $Err = "Email and password invalid";
            }
        }