<?php

session_start();

if (isset($_SESSION['userLogin'])) {
    header('location:sky10EcommerceAdminDashboard.php');
};

include 'sky9connect.php';


$emailerr = $passerr = "";
$IEmail = $IPassword = "";
$requirement = true;
$Err = "";

if (isset($_POST['submit'])) {

    // Email validation
    if (empty($_POST['email'])) {
        $emailerr = "Email is required";
        $requirement = false;
    } else {
        $email = $_POST['email'];
        $IEmail = $email;

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $emailerr = "Invalid email format";
            $requirement = false;
        }
    }

    // Password validation
    // {8,10}$
    if (empty($_POST['pass'])) {
        $passerr = "Password is required";
        $requirement = false;
    } else {
        $pass = $_POST['pass'];
        $IPassword = $pass;
        if(!is_string($pass)){
            $requirement = false;
        }
    }

    if($requirement){

        // // // 

        // $sql = "SELECT * FROM users WHERE username = ? AND password = ?";
        // $stmt = mysqli_prepare($conn, $sql);
        // mysqli_stmt_bind_param($stmt, "ss", $username, $password);
        
        // // Execute the prepared statement
        // mysqli_stmt_execute($stmt);
        
        // // Get result
        // $result = mysqli_stmt_get_result($stmt);
        
        // // Check if user exists
        // if (mysqli_num_rows($result) > 0) {
        //     // User authenticated successfully
        //     echo "Login successful!";
        // } else {
        //     // Invalid username or password
        //     echo "Invalid username or password!";
        // }


        // // //


        // // // //
        // $sql = "SELECT * FROM webadmintable WHERE Email='$email' AND Password='$pass'";
        // $query = mysqli_query($con, $sql);
        // // $row=mysqli_fetch_array($query);
    
        // if ($query) {
        //     if ($row = mysqli_fetch_assoc($query)) {
        //         $IEmail = $IPassword = "";
        //         $_SESSION['userLogin'] = $row['First_Name'];
        //         $_SESSION['userLName'] = $row['Last_Name'];
        //         $_SESSION['userEmail'] = $row['Email'];
        //         $_SESSION['userPassword'] = $row['Password'];

        //         if (strcmp($_SESSION['userPassword'], $pass) === 0) {
        //             // Passwords match
        //             echo $_SESSION['userLogin'];
        //             header('location:sky10EcommerceAdminDashboard.php');
        //         } else {
        //             // Passwords do not match
        //             $Err = "Invalid password";
        //             $requirement = false;
        //         }
    
               
        //     } else {
        //         $Err = "Email and password invalid";
        //     }
        // }

        // // // //


        $sql = "SELECT * FROM webadmintable WHERE Email=? AND Password=?";


        $query = mysqli_prepare($con, $sql);
        mysqli_stmt_bind_param($query, "ss", $email, $pass);
        mysqli_stmt_execute($query);

        if ($query) {
            if ($row = mysqli_stmt_get_result($query)) {
                
                if(mysqli_num_rows($row)>0){
                    // $Err = "login success";

                        $sql2 = "SELECT * FROM webadmintable WHERE Email='$email' AND Password='$pass'";
                        $query2=mysqli_query($con, $sql2);
                        if($query2){
                            $row2=mysqli_fetch_assoc($query2);
                            $IEmail = $IPassword = "";
                            $_SESSION['userLogin'] = $row2['First_Name'];
                            $_SESSION['userLName'] = $row2['Last_Name'];
                            $_SESSION['userEmail'] = $row2['Email'];
                            $_SESSION['userPassword'] = $row2['Password'];
                        }
    
                        if (strcmp($_SESSION['userPassword'], $pass) === 0) {
                            // Passwords match
                            echo $_SESSION['userLogin'];
                            header('location:sky10EcommerceAdminDashboard.php');
                        } else {
                            // Passwords do not match
                            $Err = "Invalid password";
                            $requirement = false;
                        };
                }else{
                    $Err = "Email and password invalid";
                }
               
            } else {
                $Err = "Mysqli stmt get result failed";
            }
        }else {
            $Err = "Query error";
        }
    }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login Form</title>

    <link rel="stylesheet" href="sky10EcommerceAdmin.css">

</head>

<body>
    <div class="reg">
        <div class="form-con">
            <form action="" method="POST">
                <h1 class="login-text">Login Form</h1>
                <span class="err"><?php echo $Err;   ?></span>

                <input class="inp" type="text" name="email" placeholder="Enter your email" value="<?php echo $IEmail;   ?>">
                <span class="err"><?php echo $emailerr;   ?></span>

                <input class="inp" type="text" name="pass" placeholder="Password" value="<?php echo $IPassword;   ?>">
                <span class="err"><?php echo $passerr;   ?></span>

                <div class="forgot-box">
                    <a class="forgot-text" href="sky10EcommerceAdminForgotPass.php">Forgot password?</a>
                </div>

                <input class="btn" name="submit" type="submit" value="Login">
            </form>
        </div>

        <div class="already-register">
            <p>Already have registered <a href="sky10EcommerceAdminRegister.php">click here</a>
            </p>
        </div>
    </div>
</body>

</html>