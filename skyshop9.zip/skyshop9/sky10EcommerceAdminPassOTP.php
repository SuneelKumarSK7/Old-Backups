<?php

include 'sky9connect.php';
session_start();

if (isset($_SESSION['userLogin'])) {
    header('location:sky10EcommerceAdminDashboard.php');
};

if (!isset($_SESSION['userEmail'])) {
    header('location:sky10EcommerceAdminLogin.php');
} else {
    $email = $_SESSION['userEmail'];
};

if (isset($_SESSION['check'])) {
    $check = $_SESSION['check'];
};

if (isset($_SESSION['check2'])) {
    $check = $_SESSION['check2'];
};

echo '<script>';
echo 'var isSessionSet2 = ' . (isset($_SESSION['check2']) ? 'true' : 'false') . ';';
echo '</script>';

echo '<script>';
echo 'var isSessionSet = ' . (isset($_SESSION['check']) ? 'true' : 'false') . ';';
echo '</script>';

$OTPErr = "";
$iOTP = "";
$requirement = true;
$Err = "";

if (isset($_POST['continue'])) {

    // Email validation
    if (empty($_POST['otp'])) {
        $OTPErr = "OTP is required";
        $requirement = false;
    } else {
        $OTP = $_POST['otp'];
        $iOTP = $OTP;
    }


    if ($requirement) {
        $sql = "SELECT * FROM webadmintable WHERE Email='$email' AND OTP=$OTP";
        $query = mysqli_query($con, $sql);

        if ($query) {
            if ($row = mysqli_fetch_assoc($query)) {
                $_SESSION['userEmail'] = $row['Email'];

                header('location:sky10EcommerceAdminChangePass.php');
            } else {
                $Err = "invalid OTP";
            }
        }
    }
};

?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Forgot Password OTP</title>

    <link rel="stylesheet" href="sky10EcommerceAdmin.css">
    <script type="text/javascript" src="jquery.min.js"></script>

</head>

<body>
    <div class="reg">
        <div class="form-con">
            <form action="" method="POST">
                <h1 class="login-text">Enter Your OTP</h1>
                <span class="err"><?php echo $Err;   ?></span>
                <div class="timer" id="timer"></div>

                <input class="inp" type="text" name="otp" placeholder="Enter your OTP" value="<?php echo $iOTP;   ?>">
                <span class="err"><?php echo $OTPErr;   ?></span>
                <div class="Resend" onclick="mailerCall()">Resend</div>


                <input class="btn" name="continue" type="submit" value="Continue">
            </form>
        </div>

        <div class="already-register">
            <p>Don't have an account <a href="sky10EcommerceAdminRegister.php">Register</a>
            </p>
        </div>
    </div>


    <script>
        let intervalType = localStorage.getItem('intervalType') || 1;
        let timerInterval;

        // console.log(intervalType)

        // Check if there is a previous time stored in the local storage
        let timeLeft = localStorage.getItem('timeLeft') || 120; // Default to 2 minutes if no previous time is found
        function startTimer() {
            timerInterval = setInterval(updateTimer, 100);
        }

        function updateTimer() {
            const minutes = Math.floor(timeLeft / 60);
            let seconds = timeLeft % 60;
            seconds = seconds < 10 ? '0' + seconds : seconds;
            document.getElementById('timer').textContent = `${minutes}:${seconds}`;

            if (timeLeft === 0) {
                clearInterval(timerInterval);
                localStorage.removeItem('timeLeft');
                // 
                intervalType = 2;
                localStorage.setItem('intervalType', intervalType)
                // 
                deleteOTP('<?php echo $email ?>', 'unsetCheck');
            } else {
                timeLeft--;
                localStorage.setItem('timeLeft', timeLeft); // Update the local storage with the remaining time
            }
        }
        // Call startTimer function when the page is loaded

        window.onload = function() {

            if (isSessionSet2) {
                localStorage.removeItem('timeLeft'); // Clear the stored time after it reaches zero
                localStorage.removeItem('intervalType');
                deleteOTP('', '', 'unsetCheck2')
            }

            if (isSessionSet) {
                startTimer();
            } else {
                document.getElementById('timer').textContent = '00:00';
            }

        };

        // Resend button onclick
        function mailerCall() {

            clearInterval(timerInterval);
            localStorage.removeItem('timeLeft'); // Clear the stored time after it reaches zero
            localStorage.removeItem('intervalType');

            forgotPass('Forget');
            window.location.reload();
            // window.location.href = 'sky9webphpmailer.php';
        }

        // Delete OTP After 2min
        function deleteOTP(deleteMail, unsetCheck, unsetCheck2) {
            $.ajax({
                url: "sky10EcommerceAdminDB.php",
                type: "POST",
                dataType: "JSON",
                data: {
                    deleteEmail: deleteMail,
                    unsetCheck: unsetCheck,
                    unsetCheck2: unsetCheck2
                }
            })
        }

        // resend OTP
        function forgotPass(FPData) {
            $.ajax({
                url: 'sky9webphpmailer.php',
                type: 'POST',
                dataType: 'JSON',
                data: {
                    forgotP: FPData
                }
            })
        }
    </script>

</body>

</html>