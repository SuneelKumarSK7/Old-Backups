<?php

session_start();

if (!isset($_SESSION['userLogin'])) {
    // header('location:sky10EcommerceAdminLogin.php');
};

include 'sky9connect.php';

$IpdMainImg = $IpdImg2 = $IpdImg3 = $IpdImg4 = $IpdImg5 = $IpdImg6 = $IPTitle = $IPRPrice = $IPFPrice = "";
// $IPTitle = $IPRPrice = $IPFPrice = $ITSelection = $IpdImg2 = $IpdMainImg = "";

$PTitleErr = $PRPriceErr = $PFPriceErr = $TSelectionErr = $pdMainImgErr = "";
$Err = "";

$requirement = true;
$updateClicked = false;


if (isset($_GET['pUpdateId']) && !empty($_GET['pUpdateId'])) {
    $userUpdateId = $_GET['pUpdateId'];

    $tableCode = $_SESSION['tableCode'];
    if ($tableCode === '1') {
        $sql = "SELECT * FROM `weballproducts` WHERE ID=$userUpdateId";
    } elseif ($tableCode === '2') {
        $sql = "SELECT * FROM `weballproductsb` WHERE ID=$userUpdateId";
    }

    // echo $tableCode;


    $query = mysqli_query($con, $sql);

    if (!$updateClicked) {

        if ($query) {
            while ($row = mysqli_fetch_assoc($query)) {
                $IpdMainImg = $row['CLICKIMG'];
                $IpdImg2 = $row['PDIMG2'];
                $IpdImg3 = $row['PDIMG3'];
                $IpdImg4 = $row['PDIMG4'];
                $IpdImg5 = $row['PDIMG5'];
                $IpdImg6 = $row['PDIMG6'];
                $IPTitle = $row['Product_Title'];
                $IPRPrice = $row['PReal_Price'];
                $IPFPrice = $row['PFULL_Price'];

                $IpdMainImg = strrchr($IpdMainImg, '/');
                $IpdMainImg = str_replace('/', '', $IpdMainImg);

                $IpdImg2 = strrchr($IpdImg2, '/');
                $IpdImg2 = str_replace('/', '', $IpdImg2);

                $IpdImg3 = strrchr($IpdImg3, '/');
                $IpdImg3 = str_replace('/', '', $IpdImg3);

                $IpdImg4 = strrchr($IpdImg4, '/');
                $IpdImg4 = str_replace('/', '', $IpdImg4);

                $IpdImg5 = strrchr($IpdImg5, '/');
                $IpdImg5 = str_replace('/', '', $IpdImg5);

                $IpdImg6 = strrchr($IpdImg6, '/');
                $IpdImg6 = str_replace('/', '', $IpdImg6);
            }
        }
    }
} else {
    header('location:sky10EcommerceAdminLogin.php');
}

// // // //

if (isset($_POST['updateSubmit'])) {

    $updateClicked = true;


    // PTitle validation
    if (empty($_POST['PTitle'])) {
        $PTitleErr = "Title is required";
        $requirement = false;
    } else {
        $PTitle = ucwords($_POST['PTitle']);
        $IPTitle = $PTitle;

        if (!preg_match("/^[a-zA-Z-' ]*$/", $PTitle)) {
            $PTitleErr = "Only letters allowed";
            $requirement = false;
        } elseif (strlen($PTitle) > 70) {
            $PTitleErr = "Tittle length allowed only less than 70 character";
            $requirement = false;
        } elseif (strlen($PTitle) < 3) {
            $PTitleErr = "Tittle length aloud greater than 2 character";
            $requirement = false;
        }
    }

    // PRPrice validation
    if (empty($_POST['PRPrice'])) {
        $PRPriceErr = "Price is required";
        $requirement = false;
    } else {
        $PRPrice = $_POST['PRPrice'];
        $IPRPrice = $PRPrice;

        if (!preg_match('/^[\d$₹]+$/', $PRPrice)) {
            $PRPriceErr = "Currency pattern invalid";
            $requirement = false;
        } elseif (strlen($PRPrice) > 5) {
            $PRPriceErr = "Price length allowed only less than 5 character";
            $requirement = false;
        } elseif (strlen($PRPrice) < 1) {
            $PRPriceErr = "Price length allowed greater than 0 character";
            $requirement = false;
        }
    }

    // PFPrice validation
    if (empty($_POST['PFPrice'])) {
        $PFPriceErr = "Price is required";
        $requirement = false;
    } else {
        $PFPrice = $_POST['PFPrice'];
        $IPFPrice = $PFPrice;

        if (!preg_match('/^[\d$₹]+$/', $PFPrice)) {
            $PFPriceErr = "Currency pattern invalid";
            $requirement = false;
        } elseif (strlen($PFPrice) > 5) {
            $PFPriceErr = "Price length allowed only less than 5 character";
            $requirement = false;
        } elseif (strlen($PFPrice) < 1) {
            $PFPriceErr = "Price length allowed greater than 0 character";
            $requirement = false;
        }
    }

    // tableSelection
    if (empty($_POST['tableSelection'])) {
        $TSelectionErr = "It's is required";
        $requirement = false;
    } else {
        $TSelection = $_POST['tableSelection'];
        $ITSelection = $TSelection;

        if (!preg_match('/^[\d]+$/', $TSelection)) {
            $TSelectionErr = "Only numbers allowed";
            $requirement = false;
        }
    }

    // pdImg2 validation
    if (isset($_FILES['pdImg2'])) {
        $file_name2 = $_FILES['pdImg2']['name'];
        $file_size2 = $_FILES['pdImg2']['size'];
        $file_tmp2 = $_FILES['pdImg2']['tmp_name'];
        $file_type2 = $_FILES['pdImg2']['type'];

        if (empty($file_name2) && isset($_POST['pdImg2I'])) {
            if (empty($_POST['pdImg2I'])) {
                $pdImg2 = "";
            } else {
                $pdImg2 = 'Ecommerce/' . $_POST['pdImg2I'];
                $IpdImg2 = $_POST['pdImg2I'];
            }
        } else {
            if ($requirement) {
                move_uploaded_file($file_tmp2, "ecom/" . $file_name2);
            }
            $pdImg2 = 'Ecommerce/' . $file_name2;
            $IpdImg2 = $file_name2;
        }
    }

    // pdImg3 validation
    if (isset($_FILES['pdImg3'])) {
        $file_name3 = $_FILES['pdImg3']['name'];
        $file_size3 = $_FILES['pdImg3']['size'];
        $file_tmp3 = $_FILES['pdImg3']['tmp_name'];
        $file_type3 = $_FILES['pdImg3']['type'];

        if (empty($file_name3) && isset($_POST['pdImg3I'])) {
            if (empty($_POST['pdImg3I'])) {
                $pdImg3 = "";
            } else {
                $pdImg3 = 'Ecommerce/' . $_POST['pdImg3I'];
                $IpdImg3 = $_POST['pdImg3I'];
            }
        } else {
            if ($requirement) {
                move_uploaded_file($file_tmp3, "ecom/" . $file_name3);
            }
            $pdImg3 = 'Ecommerce/' . $file_name3;
            $IpdImg3 = $file_name3;
        }
    }

    // pdImg4 validation
    if (isset($_FILES['pdImg4'])) {
        $file_name4 = $_FILES['pdImg4']['name'];
        $file_size4 = $_FILES['pdImg4']['size'];
        $file_tmp4 = $_FILES['pdImg4']['tmp_name'];
        $file_type4 = $_FILES['pdImg4']['type'];

        if (empty($file_name4) && isset($_POST['pdImg4I'])) {
            if (empty($_POST['pdImg4I'])) {
                $pdImg4 = "";
            } else {
                $pdImg4 = 'Ecommerce/' . $_POST['pdImg4I'];
                $IpdImg4 = $_POST['pdImg4I'];
            }
        } else {
            if ($requirement) {
                move_uploaded_file($file_tmp4, "ecom/" . $file_name4);
            }
            $pdImg4 = 'Ecommerce/' . $file_name4;
            $IpdImg4 = $file_name4;
        }
    }

    // pdImg5 validation
    if (isset($_FILES['pdImg5'])) {
        $file_name5 = $_FILES['pdImg5']['name'];
        $file_size5 = $_FILES['pdImg5']['size'];
        $file_tmp5 = $_FILES['pdImg5']['tmp_name'];
        $file_type5 = $_FILES['pdImg5']['type'];

        if (empty($file_name5) && isset($_POST['pdImg5I'])) {
            if (empty($_POST['pdImg5I'])) {
                $pdImg5 = "";
            } else {
                $pdImg5 = 'Ecommerce/' . $_POST['pdImg5I'];
                $IpdImg5 = $_POST['pdImg5I'];
            }
        } else {
            if ($requirement) {
                move_uploaded_file($file_tmp5, "ecom/" . $file_name5);
            }
            $pdImg5 = 'Ecommerce/' . $file_name5;
            $IpdImg5 = $file_name5;
        }
    }

    // pdImg6 validation
    if (isset($_FILES['pdImg6'])) {
        $file_name6 = $_FILES['pdImg6']['name'];
        $file_size6 = $_FILES['pdImg6']['size'];
        $file_tmp6 = $_FILES['pdImg6']['tmp_name'];
        $file_type6 = $_FILES['pdImg6']['type'];

        if (empty($file_name6) && isset($_POST['pdImg6I'])) {
            if (empty($_POST['pdImg6I'])) {
                $pdImg6 = "";
            } else {
                $pdImg6 = 'Ecommerce/' . $_POST['pdImg6I'];
                $IpdImg6 = $_POST['pdImg6I'];
            }
        } else {
            if ($requirement) {
                move_uploaded_file($file_tmp6, "ecom/" . $file_name6);
            }
            $pdImg6 = 'Ecommerce/' . $file_name6;
            $IpdImg6 = $file_name6;
        }
    }

    // pdMainImg validation
    if (isset($_FILES['pdMainImg'])) {

        $file_name = $_FILES['pdMainImg']['name'];
        $file_size = $_FILES['pdMainImg']['size'];
        $file_tmp = $_FILES['pdMainImg']['tmp_name'];
        $file_type = $_FILES['pdMainImg']['type'];

        // $ggt = $_POST['pdMainImgI'];

        // echo $ggt;

        if (empty($file_name) && isset($_POST['pdMainImgI'])) {
            if (empty($_POST['pdMainImgI'])) {
                $pdMainImgErr = "Product image is required";
                $requirement = false;
            } else {
                $pdMainImg = 'Ecommerce/' . $_POST['pdMainImgI'];
                $IpdMainImg = $_POST['pdMainImgI'];
            }
        } else {
            if ($requirement) {
                move_uploaded_file($file_tmp, "ecom/" . $file_name);
            }
            $pdMainImg = 'Ecommerce/' . $file_name;
            $IpdMainImg = $file_name;
        }
    }

    // $PTitle || $PRPrice || $PFPrice || $pdMainImg
    if (empty($PTitle) || empty($PRPrice) || empty($PFPrice) || empty($pdMainImg)) {
        $Err = "Please fill all requirement";
        $requirement = false;
    } elseif ($PTitle && $PRPrice && $PFPrice && $pdMainImg) {

        if ($requirement) {

            if ($tableCode === '1') {
                $sql = "UPDATE weballproducts SET CLICKIMG='$pdMainImg', PDIMG1='$pdMainImg',PDIMG2='$pdImg2', PDIMG3='$pdImg3',PDIMG4='$pdImg4', PDIMG5='$pdImg5',PDIMG6='$pdImg6',Product_Title='$PTitle',PReal_Price='$PRPrice',PFULL_Price='$PFPrice' WHERE ID=$userUpdateId";
            } elseif ($tableCode === '2') {
                // (CLICKIMG,PDIMG1,PDIMG2,PDIMG3,PDIMG4,PDIMG5,PDIMG6,Product_Title,PReal_Price,PFULL_Price) VALUES 
                // ('$pdMainImg','$pdMainImg','$pdImg2','$pdImg3','$pdImg4','$pdImg5','$pdImg6','$PTitle','$PRPrice','$PFPrice')";
                $sql = "UPDATE weballproductsb SET CLICKIMG='$pdMainImg', PDIMG1='$pdMainImg',PDIMG2='$pdImg2', PDIMG3='$pdImg3',PDIMG4='$pdImg4', PDIMG5='$pdImg5',PDIMG6='$pdImg6',Product_Title='$PTitle',PReal_Price='$PRPrice',PFULL_Price='$PFPrice' WHERE ID=$userUpdateId";
            }

            $query = mysqli_query($con, $sql);

            if ($query) {
                $UIpdMainImg = $UIpdImg2 = $UIpdImg3 = $UIpdImg4 = $UIpdImg5 = $UIpdImg6 = $UIPTitle = $UIPRPrice = $UIPFPrice = "";

                // echo "data inserted successful";
                header('location:sky10EcommerceAdminDashboard.php');
            } else {
                echo "data not inserted successful";
                // die(mysqli_error($con));
            }
        }
    }
}


?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Update Form</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" />

    <link rel="stylesheet" href="sky10EcommerceAdmin.css">

</head>

<body>
    <div class="container">
        <div class="container-b">

            <div class="dashboard-admin-update-container">
                <form class="add-more-form" action="" method="post" enctype="multipart/form-data">
                    <h1 class="add-more-action-name">Update Products</h1>

                    <div class="add-more-FLname">
                        <div class="add-more-Fname">
                            <input class="add-input input-fname" type="text" name="PTitle" id="" placeholder="Enter product title" value="<?php echo $IPTitle ?>">
                            <span class="err errA"><?php echo $PTitleErr ?></span>

                        </div>

                        <div class="add-more-Lname">
                            <input class="add-input input-lname" type="text" name="PRPrice" id="" placeholder="Enter real price" value="<?php echo $IPRPrice ?>">
                            <span class="err errB"><?php echo $PRPriceErr ?></span>

                        </div>

                    </div>

                    <div class="add-more-EN">
                        <div class="add-more-email">
                            <input class="add-input input-email" type="text" name="PFPrice" id="" placeholder="Enter full price" value="<?php echo $IPFPrice ?>">
                            <span class="err errC"><?php echo $PFPriceErr ?></span>

                        </div>

                        <div class="add-more-number">
                            <select class="add-input add-more-table-selection" name="tableSelection" id="">
                                <option value="1">Top Picks</option>
                                <option value="2">New Arrivals</option>
                            </select>

                            <span class="err errD"><?php  ?></span>
                        </div>


                    </div>

                    <!--  -->

                    <div class="add-more-PD12">
                        <div class="add-more-PD1">
                            <input class="product-detail-file-input" type="file" name="pdMainImg" accept="image/*" id="product-detail-file-input" value="<?php echo $IpdMainImg ?>">
                            <input type="text" class="pdMainImg-input images-inputs" name="pdMainImgI" value="<?php echo $IpdMainImg ?>">
                            <label class="product-detail-file-input-label" for="product-detail-file-input"><span class="product-detail-label-span"><?php echo $IpdMainImg ?></span>
                                <div class="product-detail-file-input2">
                                    <i class="fa-solid fa-cloud-arrow-up"></i> Upload image
                                </div>
                            </label>

                            <span class="err errE"><?php echo $pdMainImgErr ?></span>
                        </div>

                        <!--  -->

                        <input class="product-detail-IMG2 img-file-input" type="file" name="pdImg2" accept="image/*" id="product-detail-IMG2" value="<?php echo $IpdImg2 ?>">
                        <input type="text" class="pdImg2-input images-inputs" name="pdImg2I" value="<?php echo $IpdImg2 ?>">
                        <label class="product-detail-IMG2-label file-img-label" for="product-detail-IMG2"><span class="product-detail-label-span-IMG2"><?php echo $IpdImg2 ?></span>
                            <div class="product-detail-file-input2">
                                <i class="fa-solid fa-cloud-arrow-up"></i> Upload image
                            </div>
                        </label>

                    </div>

                    <div class="add-more-PD34">
                        <input class="product-detail-IMG3 img-file-input" type="file" name="pdImg3" accept="image/*" id="product-detail-IMG3" value="<?php echo $IpdImg3 ?>">
                        <input type="text" class="pdImg3-input images-inputs" name="pdImg3I" value="<?php echo $IpdImg3 ?>">

                        <label class="product-detail-IMG3-label file-img-label" for="product-detail-IMG3"><span class="product-detail-label-span-IMG3"><?php echo $IpdImg3 ?></span>
                            <div class="product-detail-file-input2">
                                <i class="fa-solid fa-cloud-arrow-up"></i> Upload image
                            </div>
                        </label>

                        <!--  -->

                        <input class="product-detail-IMG4 img-file-input" type="file" name="pdImg4" accept="image/*" id="product-detail-IMG4" value="<?php echo $IpdImg4 ?>">
                        <input type="text" class="pdImg4-input images-inputs" name="pdImg4I" value="<?php echo $IpdImg4 ?>">

                        <label class="product-detail-IMG4-label file-img-label" for="product-detail-IMG4"><span class="product-detail-label-span-IMG4"><?php echo $IpdImg4 ?></span>
                            <div class="product-detail-file-input2">
                                <i class="fa-solid fa-cloud-arrow-up"></i> Upload image
                            </div>
                        </label>
                    </div>

                    <div class="add-more-PD56">
                        <input class="product-detail-IMG5 img-file-input" type="file" name="pdImg5" accept="image/*" id="product-detail-IMG5" value="<?php echo $IpdImg5 ?>">
                        <input type="text" class="pdImg5-input images-inputs" name="pdImg5I" value="<?php echo $IpdImg5 ?>">

                        <label class="product-detail-IMG5-label file-img-label" for="product-detail-IMG5"><span class="product-detail-label-span-IMG5"><?php echo $IpdImg5 ?></span>
                            <div class="product-detail-file-input2">
                                <i class="fa-solid fa-cloud-arrow-up"></i> Upload image
                            </div>
                        </label>

                        <!--  -->

                        <input class="product-detail-IMG6 img-file-input" type="file" name="pdImg6" accept="image/*" id="product-detail-IMG6" value="<?php echo $IpdImg6 ?>">
                        <input type="text" class="pdImg6-input images-inputs" name="pdImg6I" value="<?php echo $IpdImg6 ?>">

                        <label class="product-detail-IMG6-label file-img-label" for="product-detail-IMG6"><span class="product-detail-label-span-IMG6"><?php echo $IpdImg6 ?></span>
                            <div class="product-detail-file-input2">
                                <i class="fa-solid fa-cloud-arrow-up"></i> Upload image
                            </div>
                        </label>
                    </div>

                    <!--  -->

                    <input class="add-submit" name="updateSubmit" type="submit" value="SUBMIT">

                </form>

            </div>

        </div>
    </div>


    <script>
        // img file selection database
        // main img 
        let mainIMG = document.getElementById('product-detail-file-input');
        mainIMG.addEventListener('change', function() {
            var fileName = this.value.split('\\').pop();
            // console.log(fileName);
            document.querySelector('.product-detail-label-span').innerText = fileName || 'No file chosen';
            document.querySelector('.pdMainImg-input').value = fileName || 'No file chosen';
        });

        // 2 img 
        let PDIMG2 = document.getElementById('product-detail-IMG2');
        PDIMG2.addEventListener('change', function() {
            var fileName = this.value.split('\\').pop();
            // console.log(fileName);
            document.querySelector('.product-detail-label-span-IMG2').innerText = fileName || 'No file chosen';
            document.querySelector('.pdImg2-input').value = fileName || 'No file chosen';
        });

        // 3 img 
        let PDIMG3 = document.getElementById('product-detail-IMG3');
        PDIMG3.addEventListener('change', function() {
            var fileName = this.value.split('\\').pop();
            // console.log(fileName);
            document.querySelector('.product-detail-label-span-IMG3').innerText = fileName || 'No file chosen';
            document.querySelector('.pdImg3-input').value = fileName || 'No file chosen';

        });

        // 4 img 
        let PDIMG4 = document.getElementById('product-detail-IMG4')
        PDIMG4.addEventListener('change', function() {
            var fileName = this.value.split('\\').pop();
            // console.log(fileName);
            document.querySelector('.product-detail-label-span-IMG4').innerText = fileName || 'No file chosen';
            document.querySelector('.pdImg4-input').value = fileName || 'No file chosen';

        });

        // 5 img 
        let PDIMG5 = document.getElementById('product-detail-IMG5')

        PDIMG5.addEventListener('change', function() {
            var fileName = this.value.split('\\').pop();
            // console.log(fileName);
            document.querySelector('.product-detail-label-span-IMG5').innerText = fileName || 'No file chosen';
            document.querySelector('.pdImg5-input').value = fileName || 'No file chosen';

        });

        // 6 img 
        let PDIMG6 = document.getElementById('product-detail-IMG6')

        PDIMG6.addEventListener('change', function() {
            var fileName = this.value.split('\\').pop();
            // console.log(fileName);
            document.querySelector('.product-detail-label-span-IMG6').innerText = fileName || 'No file chosen';
            document.querySelector('.pdImg6-input').value = fileName || 'No file chosen';

        });
    </script>
</body>

</html>