



// 14 footer-main-container

let footerHeadingDropDownA=document.querySelector('.footer-heading-dropDown-a')
let footerHeadingDropDownB=document.querySelector('.footer-heading-dropDown-b')
let footerHeadingDropDownC=document.querySelector('.footer-heading-dropDown-c')
let footerHeadingDropDownD=document.querySelector('.footer-heading-dropDown-d')

// 

let footerAllTextA=document.querySelector('.footer-all-text-a')
let footerAllTextB=document.querySelector('.footer-all-text-b')
let footerAllTextC=document.querySelector('.footer-all-text-c')
let footerAllTextD=document.querySelector('.footer-all-text-d')




footerHeadingDropDownA.addEventListener('click',()=>{
    footerAllTextA.classList.toggle('footer-heading-dropDown-toggle-a');
    console.log("clicked")
})

footerHeadingDropDownB.addEventListener('click',()=>{
    footerAllTextB.classList.toggle('footer-heading-dropDown-toggle-b');
})

footerHeadingDropDownC.addEventListener('click',()=>{
    footerAllTextC.classList.toggle('footer-heading-dropDown-toggle-c');
})

footerHeadingDropDownD.addEventListener('click',()=>{
    footerAllTextD.classList.toggle('footer-heading-dropDown-toggle-d');
})



// 
// 1 desktop menubar main container

let desktopMenuContainer=document.querySelector('#desktop-menu-container');

window.addEventListener('scroll',function(){
    if(window.pageYOffset>=136){
            desktopMenuContainer.classList.add("desktop-menu-container-sticky");

    }else{
        desktopMenuContainer.classList.remove("desktop-menu-container-sticky");

    }
})


//1(a) desktop-search-icon

let desktopSearchDropdownMainCon=document.querySelector(".desktop-search-dropdown-main-con");
let desktopSearchIcon=document.querySelector("#desktop-search-icon");
let desktopDropdownFaXmark=document.querySelector("#desktop-search-dropdown-fa-xmark")
let desktopSearchDropdown=document.querySelector(".desktop-search-dropdown");
let body=document.querySelector("body");
let desktopSearchDropdownEnterOrNot=false;


desktopSearchIcon.addEventListener("click",()=>{
    desktopSearchDropdownMainCon.style.display='block';
    body.style.overflow="hidden";

    setTimeout(() => {
        
        desktopSearchDropdown.classList.add("desktop-search-dropdown-add");
    
        currencySectionDropdown.classList.remove("currency-section-container-opacity")
        setTimeout(() => {
            setTimeout(() => {
                currencySectionDropdown.classList.remove("currency-section-container-display");
                desktopCountryCurrencyClick=false;
            }, 300);
        })
    
        languageSectionDropdown.classList.remove("language-section-container-opacity")
        setTimeout(() => {
            setTimeout(() => {
                languageSectionDropdown.classList.remove("language-section-container-display");
                desktopCountryLanguageClick=false;
            }, 300);
        })

    }, 40);

    
})

desktopDropdownFaXmark.addEventListener("click",()=>{
    desktopSearchDropFunction();
})



let desktopSearchDropFunction=()=>{
    desktopSearchDropdown.classList.remove("desktop-search-dropdown-add");
    body.style.overflow="scroll";

    setTimeout(() => {
        desktopSearchDropdownMainCon.style.display='none';
        body.style.overflow="scroll";
    }, 700);
}


// 

desktopSearchDropdown.addEventListener('mouseenter',()=>{
    desktopSearchDropdownEnterOrNot=true;
})

desktopSearchDropdown.addEventListener('mouseleave',()=>{
    desktopSearchDropdownEnterOrNot=false;
})

desktopSearchDropdownMainCon.addEventListener('click',()=>{
    if(!desktopSearchDropdownEnterOrNot){
        desktopSearchDropFunction();
    }
})

// 


//1(b) desktop-user-icon
let desktopUserMainBox=document.querySelector(".desktop-user-mainBox");



let desktopUserIcon=document.querySelector("#desktop-user-icon");
let desktopUserDropdown=document.querySelector(".desktop-user-dropdown");
let desktopLoginForm=document.querySelector(".desktop-login-form");
let desktopUserDropdownXMark=document.querySelector("#desktop-user-dropdown-fa-xmark");
let desktopLoginFormEnter=false;

desktopUserIcon.addEventListener("click",()=>{
    desktopUserDropdown.style.display="block";
    desktopUserDropdown.style.display="flex";
    desktopUserDropdown.style.opacity="1";

    desktopUserMainBox.style.opacity="1";
    body.style.overflow="hidden";

})

desktopLoginForm.addEventListener("mouseenter",()=>{
    desktopLoginFormEnter=true;
})
desktopLoginForm.addEventListener("mouseleave",()=>{
    desktopLoginFormEnter=false;
})

let desktopUser=()=>{
    body.style.overflow="scroll";

    desktopUserMainBox.classList.add("desktop-login-animation")

    desktopUserDropdown.style.opacity="0";
    desktopUserMainBox.style.opacity="0";

    setTimeout(() => {
        desktopUserDropdown.style.display="none";
        desktopUserMainBox.classList.remove("desktop-login-animation");
    }, 390);
}

desktopUserDropdownXMark.addEventListener("click",desktopUser)

desktopUserDropdown.addEventListener("click",()=>{
    if(!desktopLoginFormEnter){
        desktopUser();
    }
})



//1(c) desktop-cart-slide-con

let cartMainBackground=document.querySelector(".cart-main-background");
let desktopCartIcon=document.querySelector(".desktop-cart-icon");
let desktopCartSlideCon=document.querySelector(".desktop-cart-slide-con");
let cartXMark=document.querySelector("#cart-x-mark");
let desktopCartSlideConEnter=false;

desktopCartSlideCon.addEventListener('mouseenter',()=>{
    desktopCartSlideConEnter=true;
})
desktopCartSlideCon.addEventListener('mouseleave',()=>{
    desktopCartSlideConEnter=false;
})

desktopCartIcon.addEventListener('click',()=>{
    cartMainBackground.style.display='block';
    body.style.overflow="hidden";

    setTimeout(() => {
        desktopCartSlideCon.style.right='0px';
    }, 40);
})

let cartSlide=()=>{
    desktopCartSlideCon.style.right='-431px';
    body.style.overflow="scroll";
    setTimeout(() => {
        cartMainBackground.style.display='none';
    }, 400);
}

cartXMark.addEventListener('click',cartSlide)

cartMainBackground.addEventListener('click',()=>{
    if(!desktopCartSlideConEnter){
        cartSlide();
    }
})










// 1(c) desktop text language currency type
    let desktopCountryCurrency=document.querySelector('.desktop-country-currency');
    let currencySectionDropdown=document.querySelector('.currency-section-dropdown');
    let desktopCountryCurrencyClick=false;

    desktopCountryCurrency.addEventListener('click',()=>{

        if(!desktopCountryCurrencyClick){
            currencySectionDropdown.classList.add("currency-section-container-display");
            setTimeout(() => {
                setTimeout(() => {
                    currencySectionDropdown.classList.add("currency-section-container-opacity")
                    desktopCountryCurrencyClick=true;
                }, 40);
            })

            languageSectionDropdown.classList.remove("language-section-container-opacity")
            setTimeout(() => {
                setTimeout(() => {
                    languageSectionDropdown.classList.remove("language-section-container-display");
                    desktopCountryLanguageClick=false;
                }, 300);
            })
        }

        if(desktopCountryCurrencyClick){
            currencySectionDropdown.classList.remove("currency-section-container-opacity")
            setTimeout(() => {
                setTimeout(() => {
                    currencySectionDropdown.classList.remove("currency-section-container-display");
                    desktopCountryCurrencyClick=false;
                }, 300);
            })
        }

    })


// 1(d) desktop text country language type
    let desktopCountryLanguage=document.querySelector('.desktop-country-language');
    let languageSectionDropdown=document.querySelector('.language-section-dropdown');
    let desktopCountryLanguageClick=false;

    desktopCountryLanguage.addEventListener('click',()=>{

        if(!desktopCountryLanguageClick){
            languageSectionDropdown.classList.add("language-section-container-display");
            setTimeout(() => {
                setTimeout(() => {
                    languageSectionDropdown.classList.add("language-section-container-opacity")
                    desktopCountryLanguageClick=true;
                }, 40);
            })

            currencySectionDropdown.classList.remove("currency-section-container-opacity")
            setTimeout(() => {
                setTimeout(() => {
                    currencySectionDropdown.classList.remove("currency-section-container-display");
                    desktopCountryCurrencyClick=false;
                }, 300);
            })
        }

        if(desktopCountryLanguageClick){
            languageSectionDropdown.classList.remove("language-section-container-opacity")
            setTimeout(() => {
                setTimeout(() => {
                    languageSectionDropdown.classList.remove("language-section-container-display");
                    desktopCountryLanguageClick=false;
                }, 300);
            })
        }

    })



// 1(e) desktop menubar main container dropdown

let headerTextContainerHome = document.querySelector("#header-text-container-home");
let homeDropdownContainer = document.querySelector(".home-dropdown-container")

let headerTextContainerHomeHover = false;
let headerTextContainerHomeLeave = false;

let homeDropdownContainerHover = false;
let homeDropdownContainerEnter = false;
let homeLeave = false;


// 1(f) header text container hover
headerTextContainerHome.addEventListener("mouseenter", () => {
    headerTextContainerHomeHover = true;
    headerTextContainerHomeLeave = false;
    homeDropdownContainerEnter = false;
    homeLeave = false;

    setTimeout(() => {
        homeDropdownContainer.style.display = "block";
        homeDropdownContainer.style.display = "flex";
        setTimeout(() => {
            homeDropdownContainer.style.opacity = "1";
            homeDropdownContainer.style.top = "136px";
        }, 40);
    })
})

headerTextContainerHome.addEventListener("mouseleave", () => {
    headerTextContainerHomeLeave = true;

    setTimeout(() => {
        if (!homeDropdownContainerEnter) {
            homeLeave = true;
        }
    }, .0);
    setTimeout(() => {
        if (!homeDropdownContainerHover) {
            homeDropdownContainer.style.opacity = "0";
            homeDropdownContainer.style.top = "150px";
            setTimeout(() => {
                if (!homeDropdownContainerHover) {
                    homeDropdownContainer.style.display = "none";
                }
            }, 300);
        } else if (headerTextContainerHomeHover && headerTextContainerHomeLeave) {
            homeDropdownContainer.style.opacity = "0";
            homeDropdownContainer.style.top = "150px";
            setTimeout(() => {
                if (!homeDropdownContainerHover) {
                    homeDropdownContainer.style.display = "none";
                }
            }, 300);
        }
    }, 0);

})

//1(g) home dropdown container hover
homeDropdownContainer.addEventListener("mouseenter", () => {
    homeDropdownContainerEnter = true;
    if (!homeLeave) {
        headerTextContainerHomeHover = false;
        homeDropdownContainerHover = true;

        homeDropdownContainer.style.display = "block";
        homeDropdownContainer.style.display = "flex";
        setTimeout(() => {
            homeDropdownContainer.style.opacity = "1";
            homeDropdownContainer.style.top = "136px";
        }, 40);
    }
})

homeDropdownContainer.addEventListener("mouseleave", () => {
    homeDropdownContainerHover = false;

    setTimeout(() => {
        if (!headerTextContainerHomeHover) {
            homeDropdownContainer.style.opacity = "0";
            homeDropdownContainer.style.top = "150px";
            setTimeout(() => {
                if (!headerTextContainerHomeHover) {
                    homeDropdownContainer.style.display = "none";
                }
            }, 300);
        }
    }, 0);
})



// 1(h) shop menubar main container dropdown

let headerTextContainerShop = document.querySelector("#header-text-container-shop");
let shopDropdownContainer = document.querySelector(".shop-dropdown-container");

let headerTextContainerShopHover = false;
let headerTextContainerShopLeave = false;

let shopDropdownContainerHover = false;
let shopDropdownContainerEnter = false;
let shopLeave = false;

//1(i) shop header text container hover
headerTextContainerShop.addEventListener("mouseenter", () => {
    headerTextContainerShopHover = true;
    headerTextContainerShopLeave = false;

    shopDropdownContainerEnter = false;
    shopLeave = false;

    setTimeout(() => {
        shopDropdownContainer.style.display = "block";
        shopDropdownContainer.style.display = "flex";
        setTimeout(() => {
            shopDropdownContainer.style.opacity = "1";
            shopDropdownContainer.style.top = "136px";
        }, 40);
    })
})

headerTextContainerShop.addEventListener("mouseleave", () => {
    headerTextContainerShopLeave = true;

    setTimeout(() => {
        if (!shopDropdownContainerEnter) {
            shopLeave = true;
        }
    }, .0);
    setTimeout(() => {
        if (!shopDropdownContainerHover) {
        shopDropdownContainer.style.opacity = "0";
        shopDropdownContainer.style.top = "150px";
            setTimeout(() => {
                if (!shopDropdownContainerHover) {
                    shopDropdownContainer.style.display = "none";
                }
            }, 300);
        } else if (headerTextContainerShopHover && headerTextContainerShopLeave) {
        shopDropdownContainer.style.opacity = "0";
        shopDropdownContainer.style.top = "150px";
            setTimeout(() => {
                if (!shopDropdownContainerHover) {
                    shopDropdownContainer.style.display = "none";
                }
            }, 300);
        }

    }, 0);

})

//1(j) shop dropdown container hover
shopDropdownContainer.addEventListener("mouseenter", () => {
    shopDropdownContainerEnter = true;
    if (!shopLeave) {
        headerTextContainerShopHover = false;
        shopDropdownContainerHover = true;

        shopDropdownContainer.style.display = "block";
        shopDropdownContainer.style.display = "flex";
        setTimeout(() => {
            shopDropdownContainer.style.opacity = "1";
            shopDropdownContainer.style.top = "136px";
        }, 40);
    }
})


shopDropdownContainer.addEventListener("mouseleave", () => {
    shopDropdownContainerHover = false;

    setTimeout(() => {
        if (!headerTextContainerShopHover) {
            shopDropdownContainer.style.opacity = "0";
            shopDropdownContainer.style.top = "150px";
            setTimeout(() => {
                if (!headerTextContainerShopHover) {
                    shopDropdownContainer.style.display = "none";
                }
            }, 300);
        }
    }, 0);
})


// 1(k) product menubar main container dropdown

let headerTextContainerProduct = document.querySelector("#header-text-container-product");
let productDropdownContainer = document.querySelector(".product-dropdown-container");

let headerTextContainerProductHover = false;
let headerTextContainerProductLeave = false;
let productDropdownContainerHover = false;
let productDropdownContainerEnter = false;
let productLeave = false;

//1(l) product header text container hover
headerTextContainerProduct.addEventListener("mouseenter", () => {
    headerTextContainerProductHover = true;
    headerTextContainerProductLeave = false;

    productDropdownContainerEnter = false;
    productLeave = false;

    setTimeout(() => {
        productDropdownContainer.style.display = "block";
        productDropdownContainer.style.display = "flex";
        setTimeout(() => {
            productDropdownContainer.style.opacity = "1";
            productDropdownContainer.style.top = "136px";
        }, 40);
    })
})

headerTextContainerProduct.addEventListener("mouseleave", () => {
    headerTextContainerProductLeave = true;

    setTimeout(() => {
        if (!productDropdownContainerEnter) {
            productLeave = true;
        }
    }, .0);
    setTimeout(() => {
        if (!productDropdownContainerHover) {
        productDropdownContainer.style.opacity = "0";
        productDropdownContainer.style.top = "150px";
            setTimeout(() => {
                if (!productDropdownContainerHover) {
                    productDropdownContainer.style.display = "none";
                }
            }, 300);
        } else if (headerTextContainerProductHover && headerTextContainerProductLeave) {
        productDropdownContainer.style.opacity = "0";
        productDropdownContainer.style.top = "150px";
            setTimeout(() => {
                if (!productDropdownContainerHover) {
                    productDropdownContainer.style.display = "none";
                }
            }, 300);
        }

    }, 0);

})

//1(m) product dropdown container hover
productDropdownContainer.addEventListener("mouseenter", () => {
    productDropdownContainerEnter = true;
    if (!productLeave) {
        headerTextContainerProductHover = false;
        productDropdownContainerHover = true;

        productDropdownContainer.style.display = "block";
        productDropdownContainer.style.display = "flex";
        setTimeout(() => {
            productDropdownContainer.style.opacity = "1";
            productDropdownContainer.style.top = "136px";
        }, 40);
    }
})

productDropdownContainer.addEventListener("mouseleave", () => {
    productDropdownContainerHover = false;

    setTimeout(() => {
        if (!headerTextContainerProductHover) {
            productDropdownContainer.style.opacity = "0";
            productDropdownContainer.style.top = "150px";
            setTimeout(() => {
                if (!headerTextContainerProductHover) {
                    productDropdownContainer.style.display = "none";
                }
            }, 300);
        }
    }, 0);
})



// 1(n) blog menubar main container dropdown
let headerTextContainerBlog = document.querySelector("#header-text-container-blog");
let blogDropdownContainer = document.querySelector(".blog-dropdown-container");

let headerTextContainerBlogHover = false;
let headerTextContainerBlogLeave = false;

let blogDropdownContainerHover = false;
let blogDropdownContainerEnter = false;
let blogLeave = false;

//1(o) blog header text container hover
headerTextContainerBlog.addEventListener("mouseenter", () => {
    headerTextContainerBlogHover = true;
    headerTextContainerBlogLeave = false;

    blogDropdownContainerEnter = false;
    blogLeave = false;

    setTimeout(() => {
        blogDropdownContainer.style.display = "block";
        // blogDropdownContainer.style.display = "flex";
        setTimeout(() => {
            blogDropdownContainer.style.opacity = "1";
            blogDropdownContainer.style.top = "136px";
        }, 40);
    })
})

headerTextContainerBlog.addEventListener("mouseleave", () => {
    headerTextContainerBlogLeave = true;

    setTimeout(() => {
        if (!blogDropdownContainerEnter) {
            blogLeave = true;
        }
    }, .0);
    setTimeout(() => {
        if (!blogDropdownContainerHover) {
        blogDropdownContainer.style.opacity = "0";
        blogDropdownContainer.style.top = "150px";
            setTimeout(() => {
                if (!blogDropdownContainerHover) {
                    blogDropdownContainer.style.display = "none";
                }
            }, 300);
        } else if (headerTextContainerBlogHover && headerTextContainerBlogLeave) {
        blogDropdownContainer.style.opacity = "0";
        blogDropdownContainer.style.top = "150px";
            setTimeout(() => {
                if (!blogDropdownContainerHover) {
                    blogDropdownContainer.style.display = "none";
                }
            }, 300);
        }

    }, 0);

})

//1(p) blog dropdown container hover
blogDropdownContainer.addEventListener("mouseenter", () => {
    blogDropdownContainerEnter = true;
    if (!blogLeave) {
        headerTextContainerBlogHover = false;
        blogDropdownContainerHover = true;

        // blogDropdownContainer.style.display = "block";
        blogDropdownContainer.style.display = "flex";
        setTimeout(() => {
            blogDropdownContainer.style.opacity = "1";
            blogDropdownContainer.style.top = "136px";
        }, 40);
    }
})

blogDropdownContainer.addEventListener("mouseleave", () => {
    blogDropdownContainerHover = false;

    setTimeout(() => {
        if (!headerTextContainerBlogHover) {
            blogDropdownContainer.style.opacity = "0";
            blogDropdownContainer.style.top = "150px";
            setTimeout(() => {
                if (!headerTextContainerBlogHover) {
                    blogDropdownContainer.style.display = "none";
                }
            }, 300);
        }
    }, 0);
})



// 1(q) page menubar main container dropdown
let headerTextContainerPage = document.querySelector("#header-text-container-page");
let pageDropdownContainer = document.querySelector(".page-dropdown-container");

let headerTextContainerPageHover = false;
let headerTextContainerPageLeave = false;

let pageDropdownContainerHover = false;
let pageDropdownContainerEnter = false;
let pageLeave = false;

//1(r) product page text container hover
headerTextContainerPage.addEventListener("mouseenter", () => {
    headerTextContainerPageHover = true;
    headerTextContainerPageLeave = false;

    pageDropdownContainerEnter = false;
    pageLeave = false;

    setTimeout(() => {
        pageDropdownContainer.style.display = "block";
        // blogDropdownContainer.style.display = "flex";
        setTimeout(() => {
            pageDropdownContainer.style.opacity = "1";
            pageDropdownContainer.style.top = "136px";
        }, 40);
    })
})

headerTextContainerPage.addEventListener("mouseleave", () => {
    headerTextContainerPageLeave = true;

    setTimeout(() => {
        if (!pageDropdownContainerEnter) {
            pageLeave = true;
        }
    }, .0);
    setTimeout(() => {
        if (!pageDropdownContainerHover) {
        pageDropdownContainer.style.opacity = "0";
        pageDropdownContainer.style.top = "150px";
            setTimeout(() => {
                if (!pageDropdownContainerHover) {
                    pageDropdownContainer.style.display = "none";
                }
            }, 300);
        } else if (headerTextContainerBlogHover && headerTextContainerPageLeave) {
        pageDropdownContainer.style.opacity = "0";
        pageDropdownContainer.style.top = "150px";
            setTimeout(() => {
                if (!pageDropdownContainerHover) {
                    pageDropdownContainer.style.display = "none";
                }
            }, 300);
        }

    }, 0);

})

//1(s) page dropdown container hover
pageDropdownContainer.addEventListener("mouseenter", () => {
    pageDropdownContainerEnter = true;
    if (!pageLeave) {
        headerTextContainerPageHover = false;
        pageDropdownContainerHover = true;

        // blogDropdownContainer.style.display = "block";
        pageDropdownContainer.style.display = "flex";
        setTimeout(() => {
            pageDropdownContainer.style.opacity = "1";
            pageDropdownContainer.style.top = "136px";
        }, 40);
    }
})

pageDropdownContainer.addEventListener("mouseleave", () => {
    pageDropdownContainerHover = false;

    setTimeout(() => {
        if (!headerTextContainerPageHover) {
            pageDropdownContainer.style.opacity = "0";
            pageDropdownContainer.style.top = "150px";
            setTimeout(() => {
                if (!headerTextContainerPageHover) {
                    pageDropdownContainer.style.display = "none";
                }
            }, 300);
        }
    }, 0);
})






// 1(t) menubar-main-container
let menuMainBox = document.querySelector('.menubar-main-container-box');
let menuMain = document.getElementById('menubar-main-container');
let menuImg = document.getElementById('menu-icon');
let faxMark = document.getElementById('fa-xmark');
menuBoxLeaveOrNot=false;

menuMain.addEventListener('mouseenter',()=>{menuBoxLeaveOrNot=true})
menuMain.addEventListener('mouseleave',()=>{menuBoxLeaveOrNot=false})


menuImg.addEventListener('click', () => {
    menuMainBox.style.display='block';
    body.style.overflow='hidden';

    setTimeout(() => {
        menuMain.style.left = '0px';
    }, 40);
})
faxMark.addEventListener('click', () => {
    menuScroll();
})

let menuScroll=()=>{
    menuMain.style.left = '-510px';
    body.style.overflow='scroll';
    
setTimeout(() => {
    menuMainBox.style.display='none';
    }, 500);
}

menuMainBox.addEventListener('click',()=>{
    if(!menuBoxLeaveOrNot){
        menuScroll();
    }
})



// 3 scroller carousel 

const carousel = document.querySelector(".carousel");
let isDragging = false;
let startX = "";
let startScrollLeft = "";

/// draggable card
let dragStart = (e) => {
    isDragging = true;
    carousel.classList.add("dragging");
    carousel.classList.remove("carousel-behavior");
    startX = e.pageX || e.touches[0].pageX;
    startScrollLeft = carousel.scrollLeft;
    // console.log(startScrollLeft);
    // console.log(startX);
}

let startDragging = (e) => {
    if (!isDragging) return;
    let kk = carousel.scrollLeft = startScrollLeft - ((e.pageX || e.touches[0].pageX) - startX);
    // console.log(kk)
    // console.log(e.pageX)

}

let stopDragging = () => {
    isDragging = false;
    carousel.classList.remove("dragging");
    carousel.classList.add("carousel-behavior");
}

carousel.addEventListener("mousedown", dragStart)
carousel.addEventListener("touchstart", dragStart)

carousel.addEventListener("mousemove", startDragging)
window.addEventListener("mousemove", startDragging)
carousel.addEventListener("touchmove", startDragging)

carousel.addEventListener("mouseup", stopDragging)
window.addEventListener("mouseup", stopDragging)
carousel.addEventListener("touchend", stopDragging)



/// next preview button

let left = document.querySelector(".left");
let right = document.querySelector(".right");
let leftA = document.getElementById("left-scroll");
let rightA = document.getElementById("right-scroll");
// let cardWidth = document.querySelector(".card").offsetWidth;
// console.log(cardWidth)

// setInterval(() => {
//     if (carousel.scrollLeft >= 387) {
//         rightA.style.display = "none";
//     }
//     if (carousel.scrollLeft < 387) {
//         rightA.style.display = "block";
//         rightA.style.display = "flex";
//     }
//     if (carousel.scrollLeft <= 0) {
//         leftA.style.display = "none";
//     }
//     if (carousel.scrollLeft > 0) {
//         leftA.style.display = "block";
//         leftA.style.display = "flex";
//     }
// }, 0)

right.addEventListener("click", () => {
    carousel.classList.add("carousel-behavior");
    if (carousel.scrollLeft <= 0 || carousel.scrollLeft >= 0) {
        rightA.style.display = "block";
        rightA.style.display = "flex";
        carousel.scrollLeft += cardWidth + 20;
        // carousel.scrollLeft += (cardWidth * 6 + 100) * 1 / 4;
        // console.log(carousel.scrollLeft)
    }
})

left.addEventListener("click", () => {
    carousel.classList.add("carousel-behavior");
    if (carousel.scrollLeft >= 1) {
        leftA.style.display = "block";
        leftA.style.display = "flex";
        carousel.scrollLeft += -(cardWidth + 20);
        // carousel.scrollLeft += -((cardWidth * 6 + 100) * 1 / 4);
        // console.log(carousel.scrollLeft)
    }
})


//second(2) carousel

const carouselB = document.querySelector(".carousel-b");
let isDragging2 = false;
let startX2 = "";
let startScrollLeft2 = "";

/// draggable card
let dragStart2 = (e) => {
    isDragging2 = true;
    carouselB.classList.add("dragging");
    carouselB.classList.remove("carousel-behavior-B");
    startX2 = e.pageX || e.touches[0].pageX;
    startScrollLeft2 = carouselB.scrollLeft;
    // console.log(startScrollLeft);
    // console.log(startX);
}

let startDragging2 = (e) => {
    if (!isDragging2) return;
    let kk = carouselB.scrollLeft = startScrollLeft2 - ((e.pageX || e.touches[0].pageX) - startX2);
    // console.log(kk)
}

let stopDragging2 = () => {
    isDragging2 = false;
    carouselB.classList.remove("dragging");
    carouselB.classList.add("carousel-behavior-B");
}

carouselB.addEventListener("mousedown", dragStart2)
carouselB.addEventListener("touchstart", dragStart2)

carouselB.addEventListener("mousemove", startDragging2)
window.addEventListener("mousemove", startDragging2)
carouselB.addEventListener("touchmove", startDragging2)

carouselB.addEventListener("mouseup", stopDragging2)
window.addEventListener("mouseup", stopDragging2)
carouselB.addEventListener("touchend", stopDragging2)



/// next preview button

let leftB = document.querySelector(".left-B");
let rightB = document.querySelector(".right-B");
let leftC = document.getElementById("left-scroll-C");
let rightC = document.getElementById("right-scroll-C");
let cardWidthB = document.querySelector(".card-B").offsetWidth;
// console.log(cardWidth)

// setInterval(() => {
//     if (carouselB.scrollLeft >= 387) {
//         rightC.style.display = "none";
//     }
//     if (carouselB.scrollLeft < 387) {
//         rightC.style.display = "block";
//         rightC.style.display = "flex";
//     }
//     if (carouselB.scrollLeft <= 0) {
//         leftC.style.display = "none";
//     }
//     if (carouselB.scrollLeft > 0) {
//         leftC.style.display = "block";
//         leftC.style.display = "flex";
//     }
// }, 0)

rightB.addEventListener("click", () => {
    carouselB.classList.add("carousel-behavior-B");
    if (carouselB.scrollLeft <= 0 || carouselB.scrollLeft >= 0) {
        rightA.style.display = "block";
        rightA.style.display = "flex";
        carouselB.scrollLeft += cardWidth + 20;
        // console.log(carouselB.scrollLeft)
    }
})

leftB.addEventListener("click", () => {
    carouselB.classList.add("carousel-behavior-B");
    if (carouselB.scrollLeft >= 1) {
        leftA.style.display = "block";
        leftA.style.display = "flex";
        carouselB.scrollLeft += -(cardWidth + 20);
        // console.log(carouselB.scrollLeft)
    }
})




//2 slideshow-container

// slideshow text
// 1st
let sliderText = document.querySelector('#slider-text');
let sliderTextB = document.querySelector('#slider-text-b');
let sliderTextC = document.querySelector('#slider-text-c');
let sliderBTN = document.querySelector('#slider-btn');


// 2nd
let sliderText2 = document.querySelector('#slider-text-2');
let sliderTextB2 = document.querySelector('#slider-text-b-2');
let sliderTextC2 = document.querySelector('#slider-text-c-2');
let sliderBTN2 = document.querySelector('#slider-btn-2');


// 3rd
let sliderText3 = document.querySelector('#slider-text-3');
let sliderTextB3 = document.querySelector('#slider-text-b-3');
let sliderTextC3 = document.querySelector('#slider-text-c-3');
let sliderBTN3 = document.querySelector('#slider-btn-3');


// 4rth
let sliderText4 = document.querySelector('#slider-text-4');
let sliderTextB4 = document.querySelector('#slider-text-b-4');
let sliderTextC4 = document.querySelector('#slider-text-c-4');
let sliderBTN4 = document.querySelector('#slider-btn-4');

// 

var a = 0;

var slideshowImg = document.getElementById('slideshow-img');

let sliderA = document.getElementById('slider-con-a')
let sliderB = document.getElementById('slider-con-b')
let sliderC = document.getElementById('slider-con-c')
let sliderD = document.getElementById('slider-con-d')

let slideEnter=false;

var slideShowInterval;

setTimeout(() => {
    sliderA.style.display = 'block';
    sliderB.style.display = 'none';
    sliderC.style.display = 'none';
    sliderD.style.display = 'none';

    // 
    sliderText.style.opacity = '0';
    sliderTextB.style.opacity = '0';
    sliderTextC.style.opacity = '0';
    sliderBTN.style.opacity = '0';

    setTimeout(() => {
        sliderText.style.opacity = '1';
    }, 700);
    setTimeout(() => {
        sliderTextB.style.opacity = '1';
    }, 1100);
    setTimeout(() => {
        sliderTextC.style.opacity = '1';
    }, 1500);
    setTimeout(() => {
        sliderBTN.style.opacity = '1';
    }, 1900);
    // 

}, 0);

startSlide = () => {

     slideShowInterval = setInterval(() => {
        if (a < 3) {
            a++;

            if (a == 1) {
                sliderA.style.display = 'none';
                sliderB.style.display = 'block';
                sliderC.style.display = 'none';
                sliderD.style.display = 'none';

                sliderText2.style.opacity = '0';
                sliderTextB2.style.opacity = '0';
                sliderTextC2.style.opacity = '0';
                sliderBTN2.style.opacity = '0';


                setTimeout(() => {
                    sliderText2.style.opacity = '1';
                }, 700);
                setTimeout(() => {
                    sliderTextB2.style.opacity = '1';
                }, 1100);
                setTimeout(() => {
                    sliderTextC2.style.opacity = '1';
                }, 1500);
                setTimeout(() => {
                    sliderBTN2.style.opacity = '1';
                }, 1900);



            }
            if (a == 2) {

                sliderA.style.display = 'none';
                sliderB.style.display = 'none';
                sliderC.style.display = 'block';
                sliderD.style.display = 'none';

                sliderText3.style.opacity = '0';
                sliderTextB3.style.opacity = '0';
                sliderTextC3.style.opacity = '0';
                sliderBTN3.style.opacity = '0';

                setTimeout(() => {
                    sliderText3.style.opacity = '1';
                }, 700);
                setTimeout(() => {
                    sliderTextB3.style.opacity = '1';
                }, 1100);
                setTimeout(() => {
                    sliderTextC3.style.opacity = '1';
                }, 1500);
                setTimeout(() => {
                    sliderBTN3.style.opacity = '1';
                }, 1900);

            }
            if (a == 3) {
                sliderA.style.display = 'none';
                sliderB.style.display = 'none';
                sliderC.style.display = 'none';
                sliderD.style.display = 'block';

                sliderText4.style.opacity = '0';
                sliderTextB4.style.opacity = '0';
                sliderTextC4.style.opacity = '0';
                sliderBTN4.style.opacity = '0';


                setTimeout(() => {
                    sliderText4.style.opacity = '1';
                }, 700);
                setTimeout(() => {
                    sliderTextB4.style.opacity = '1';
                }, 1100);
                setTimeout(() => {
                    sliderTextC4.style.opacity = '1';
                }, 1500);
                setTimeout(() => {
                    sliderBTN4.style.opacity = '1';
                }, 1900);

            }
        } else {
            a = 0;
            sliderA.style.display = 'block';
            sliderB.style.display = 'none';
            sliderC.style.display = 'none';
            sliderD.style.display = 'none';

            sliderText.style.opacity = '0';
            sliderTextB.style.opacity = '0';
            sliderTextC.style.opacity = '0';
            sliderBTN.style.opacity = '0';

            setTimeout(() => {
                sliderText.style.opacity = '1';
            }, 700);
            setTimeout(() => {
                sliderTextB.style.opacity = '1';
            }, 1100);
            setTimeout(() => {
                sliderTextC.style.opacity = '1';
            }, 1500);
            setTimeout(() => {
                sliderBTN.style.opacity = '1';
            }, 1900);

        }
    }, 3500)

    slideshowImg.addEventListener("mouseenter", () => {
        clearInterval(slideShowInterval);
    })

    slideshowImg.addEventListener("touchstart", () => {
        clearInterval(slideShowInterval);
    })

    

}

slideshowImg.addEventListener("mouseleave", () => {
    startSlide();
})

slideshowImg.addEventListener("touchend", () => {
    startSlide();
})

startSlide();


// 
// 

let slideIsDragging = false;
let slideStartX = "";
let slideStartScrollLeft = "";
let sSlide="";
let slideIsDraggingOrNot=false;


let slideDragStart = (e) => {
    slideIsDragging = true;
    
    slideStartX = e.pageX || e.touches[0].pageX;
    slideStartScrollLeft = slideshowImg.scrollLeft;
    // console.log(slideStartScrollLeft);
    // console.log(startX);
}

let slideStartDragging = (e) => {
    if (!slideIsDragging){
        return;
    } else {
        sSlide = slideshowImg.scrollLeft = slideStartScrollLeft - ((e.pageX || e.touches[0].pageX) - slideStartX);
        slideIsDraggingOrNot=true;
        // console.log(sSlide)
    };
    // console.log(e.pageX)
    console.log('dragging')


}

let slideStopDragging = () => {
    slideIsDragging = false;
    // console.log("e.pageX")
    // console.log(sSlide)
    if(!slideIsDraggingOrNot){
        // console.log("false")
        return;
        
    }else{
        // console.log("true")

        slideIsDraggingOrNot=false;
        
        if(sSlide>40 && !sSlide==""){

                if (a < 3) {
                a++;

                if (a == 1) {
                    console.log(a);
                    sliderA.style.display = 'none';
                    sliderB.style.display = 'block';
                    sliderC.style.display = 'none';
                    sliderD.style.display = 'none';

                    sliderText2.style.opacity = '0';
                    sliderTextB2.style.opacity = '0';
                    sliderTextC2.style.opacity = '0';
                    sliderBTN2.style.opacity = '0';


                    setTimeout(() => {
                        sliderText2.style.opacity = '1';
                    }, 700);
                    setTimeout(() => {
                        sliderTextB2.style.opacity = '1';
                    }, 1100);
                    setTimeout(() => {
                        sliderTextC2.style.opacity = '1';
                    }, 1500);
                    setTimeout(() => {
                        sliderBTN2.style.opacity = '1';
                    }, 1900);



                }
                if (a == 2) {
                    console.log(a);

                    sliderA.style.display = 'none';
                    sliderB.style.display = 'none';
                    sliderC.style.display = 'block';
                    sliderD.style.display = 'none';

                    sliderText3.style.opacity = '0';
                    sliderTextB3.style.opacity = '0';
                    sliderTextC3.style.opacity = '0';
                    sliderBTN3.style.opacity = '0';

                    setTimeout(() => {
                        sliderText3.style.opacity = '1';
                    }, 700);
                    setTimeout(() => {
                        sliderTextB3.style.opacity = '1';
                    }, 1100);
                    setTimeout(() => {
                        sliderTextC3.style.opacity = '1';
                    }, 1500);
                    setTimeout(() => {
                        sliderBTN3.style.opacity = '1';
                    }, 1900);

                }
                if (a == 3) {
                    console.log(a);

                    sliderA.style.display = 'none';
                    sliderB.style.display = 'none';
                    sliderC.style.display = 'none';
                    sliderD.style.display = 'block';

                    sliderText4.style.opacity = '0';
                    sliderTextB4.style.opacity = '0';
                    sliderTextC4.style.opacity = '0';
                    sliderBTN4.style.opacity = '0';


                    setTimeout(() => {
                        sliderText4.style.opacity = '1';
                    }, 700);
                    setTimeout(() => {
                        sliderTextB4.style.opacity = '1';
                    }, 1100);
                    setTimeout(() => {
                        sliderTextC4.style.opacity = '1';
                    }, 1500);
                    setTimeout(() => {
                        sliderBTN4.style.opacity = '1';
                    }, 1900);

                }
            } else {
                a = 0;
                console.log(a);

                sliderA.style.display = 'block';
                sliderB.style.display = 'none';
                sliderC.style.display = 'none';
                sliderD.style.display = 'none';

                sliderText.style.opacity = '0';
                sliderTextB.style.opacity = '0';
                sliderTextC.style.opacity = '0';
                sliderBTN.style.opacity = '0';

                setTimeout(() => {
                    sliderText.style.opacity = '1';
                }, 700);
                setTimeout(() => {
                    sliderTextB.style.opacity = '1';
                }, 1100);
                setTimeout(() => {
                    sliderTextC.style.opacity = '1';
                }, 1500);
                setTimeout(() => {
                    sliderBTN.style.opacity = '1';
                }, 1900);
                
            }
        }
        
        if(sSlide<-40 && !sSlide==""){

                    if (a > 0) {
                        a--;
            
                        if (a == 1) {
                            sliderA.style.display = 'none';
                            sliderB.style.display = 'block';
                            sliderC.style.display = 'none';
                            sliderD.style.display = 'none';
            
                            sliderText2.style.opacity = '0';
                            sliderTextB2.style.opacity = '0';
                            sliderTextC2.style.opacity = '0';
                            sliderBTN2.style.opacity = '0';
            
            
                            setTimeout(() => {
                                sliderText2.style.opacity = '1';
                            }, 700);
                            setTimeout(() => {
                                sliderTextB2.style.opacity = '1';
                            }, 1100);
                            setTimeout(() => {
                                sliderTextC2.style.opacity = '1';
                            }, 1500);
                            setTimeout(() => {
                                sliderBTN2.style.opacity = '1';
                            }, 1900);
            
            
            
                        }
                        if (a == 2) {
            
                            sliderA.style.display = 'none';
                            sliderB.style.display = 'none';
                            sliderC.style.display = 'block';
                            sliderD.style.display = 'none';
            
                            sliderText3.style.opacity = '0';
                            sliderTextB3.style.opacity = '0';
                            sliderTextC3.style.opacity = '0';
                            sliderBTN3.style.opacity = '0';
            
                            setTimeout(() => {
                                sliderText3.style.opacity = '1';
                            }, 700);
                            setTimeout(() => {
                                sliderTextB3.style.opacity = '1';
                            }, 1100);
                            setTimeout(() => {
                                sliderTextC3.style.opacity = '1';
                            }, 1500);
                            setTimeout(() => {
                                sliderBTN3.style.opacity = '1';
                            }, 1900);
            
                        }
                        if (a == 0) {
                            
                        sliderA.style.display = 'block';
                        sliderB.style.display = 'none';
                        sliderC.style.display = 'none';
                        sliderD.style.display = 'none';
            
                        sliderText.style.opacity = '0';
                        sliderTextB.style.opacity = '0';
                        sliderTextC.style.opacity = '0';
                        sliderBTN.style.opacity = '0';
            
                        setTimeout(() => {
                            sliderText.style.opacity = '1';
                        }, 700);
                        setTimeout(() => {
                            sliderTextB.style.opacity = '1';
                        }, 1100);
                        setTimeout(() => {
                            sliderTextC.style.opacity = '1';
                        }, 1500);
                        setTimeout(() => {
                            sliderBTN.style.opacity = '1';
                        }, 1900);

                        }
                    } else {
                        a = 3;
                        

                        sliderA.style.display = 'none';
                            sliderB.style.display = 'none';
                            sliderC.style.display = 'none';
                            sliderD.style.display = 'block';
            
                            sliderText4.style.opacity = '0';
                            sliderTextB4.style.opacity = '0';
                            sliderTextC4.style.opacity = '0';
                            sliderBTN4.style.opacity = '0';
            
            
                            setTimeout(() => {
                                sliderText4.style.opacity = '1';
                            }, 700);
                            setTimeout(() => {
                                sliderTextB4.style.opacity = '1';
                            }, 1100);
                            setTimeout(() => {
                                sliderTextC4.style.opacity = '1';
                            }, 1500);
                            setTimeout(() => {
                                sliderBTN4.style.opacity = '1';
                            }, 1900);
                    }
        }

    }

}


slideshowImg.addEventListener("mousedown", slideDragStart)
slideshowImg.addEventListener("touchstart", slideDragStart)

slideshowImg.addEventListener("mousemove", slideStartDragging)
// window.addEventListener("mousemove", slideStartDragging)
slideshowImg.addEventListener("touchmove", slideStartDragging)

slideshowImg.addEventListener("mouseup", slideStopDragging)
// window.addEventListener("mouseup", slideStopDragging)
slideshowImg.addEventListener("touchend", slideStopDragging)
// slideshowImg.addEventListener("mouseout", startSlide);




// 3 scroller carousel 

// const carousel = document.querySelector(".carousel");
// let isDragging = false;
// let startX = "";
// let startScrollLeft = "";

// /// draggable card
// let dragStart = (e) => {
//     isDragging = true;
//     carousel.classList.add("dragging");
//     carousel.classList.remove("carousel-behavior");
//     startX = e.pageX || e.touches[0].pageX;
//     startScrollLeft = carousel.scrollLeft;
//     // console.log(startScrollLeft);
//     // console.log(startX);
// }

// let startDragging = (e) => {
//     if (!isDragging) return;
//     let kk = carousel.scrollLeft = startScrollLeft - ((e.pageX || e.touches[0].pageX) - startX);
//     // console.log(kk)
//     // console.log(e.pageX)

// }

// let stopDragging = () => {
//     isDragging = false;
//     carousel.classList.remove("dragging");
//     carousel.classList.add("carousel-behavior");
// }

// carousel.addEventListener("mousedown", dragStart)
// carousel.addEventListener("touchstart", dragStart)

// carousel.addEventListener("mousemove", startDragging)
// window.addEventListener("mousemove", startDragging)
// carousel.addEventListener("touchmove", startDragging)

// carousel.addEventListener("mouseup", stopDragging)
// window.addEventListener("mouseup", stopDragging)
// carousel.addEventListener("touchend", stopDragging)



// /// next preview button

// let left = document.querySelector(".left");
// let right = document.querySelector(".right");
// let leftA = document.getElementById("left-scroll");
// let rightA = document.getElementById("right-scroll");
// let cardWidth = document.querySelector(".card").offsetWidth;
// // console.log(cardWidth)

// // setInterval(() => {
// //     if (carousel.scrollLeft >= 387) {
// //         rightA.style.display = "none";
// //     }
// //     if (carousel.scrollLeft < 387) {
// //         rightA.style.display = "block";
// //         rightA.style.display = "flex";
// //     }
// //     if (carousel.scrollLeft <= 0) {
// //         leftA.style.display = "none";
// //     }
// //     if (carousel.scrollLeft > 0) {
// //         leftA.style.display = "block";
// //         leftA.style.display = "flex";
// //     }
// // }, 0)

// right.addEventListener("click", () => {
//     carousel.classList.add("carousel-behavior");
//     if (carousel.scrollLeft <= 0 || carousel.scrollLeft >= 0) {
//         rightA.style.display = "block";
//         rightA.style.display = "flex";
//         carousel.scrollLeft += cardWidth + 20;
//         // carousel.scrollLeft += (cardWidth * 6 + 100) * 1 / 4;
//         // console.log(carousel.scrollLeft)
//     }
// })

// left.addEventListener("click", () => {
//     carousel.classList.add("carousel-behavior");
//     if (carousel.scrollLeft >= 1) {
//         leftA.style.display = "block";
//         leftA.style.display = "flex";
//         carousel.scrollLeft += -(cardWidth + 20);
//         // carousel.scrollLeft += -((cardWidth * 6 + 100) * 1 / 4);
//         // console.log(carousel.scrollLeft)
//     }
// })


// //second(2) carousel

// const carouselB = document.querySelector(".carousel-b");
// let isDragging2 = false;
// let startX2 = "";
// let startScrollLeft2 = "";

// /// draggable card
// let dragStart2 = (e) => {
//     isDragging2 = true;
//     carouselB.classList.add("dragging");
//     carouselB.classList.remove("carousel-behavior-B");
//     startX2 = e.pageX || e.touches[0].pageX;
//     startScrollLeft2 = carouselB.scrollLeft;
//     // console.log(startScrollLeft);
//     // console.log(startX);
// }

// let startDragging2 = (e) => {
//     if (!isDragging2) return;
//     let kk = carouselB.scrollLeft = startScrollLeft2 - ((e.pageX || e.touches[0].pageX) - startX2);
//     // console.log(kk)
// }

// let stopDragging2 = () => {
//     isDragging2 = false;
//     carouselB.classList.remove("dragging");
//     carouselB.classList.add("carousel-behavior-B");
// }

// carouselB.addEventListener("mousedown", dragStart2)
// carouselB.addEventListener("touchstart", dragStart2)

// carouselB.addEventListener("mousemove", startDragging2)
// window.addEventListener("mousemove", startDragging2)
// carouselB.addEventListener("touchmove", startDragging2)

// carouselB.addEventListener("mouseup", stopDragging2)
// window.addEventListener("mouseup", stopDragging2)
// carouselB.addEventListener("touchend", stopDragging2)



// /// next preview button

// let leftB = document.querySelector(".left-B");
// let rightB = document.querySelector(".right-B");
// let leftC = document.getElementById("left-scroll-C");
// let rightC = document.getElementById("right-scroll-C");
// let cardWidthB = document.querySelector(".card-B").offsetWidth;
// // console.log(cardWidth)

// // setInterval(() => {
// //     if (carouselB.scrollLeft >= 387) {
// //         rightC.style.display = "none";
// //     }
// //     if (carouselB.scrollLeft < 387) {
// //         rightC.style.display = "block";
// //         rightC.style.display = "flex";
// //     }
// //     if (carouselB.scrollLeft <= 0) {
// //         leftC.style.display = "none";
// //     }
// //     if (carouselB.scrollLeft > 0) {
// //         leftC.style.display = "block";
// //         leftC.style.display = "flex";
// //     }
// // }, 0)

// rightB.addEventListener("click", () => {
//     carouselB.classList.add("carousel-behavior-B");
//     if (carouselB.scrollLeft <= 0 || carouselB.scrollLeft >= 0) {
//         rightA.style.display = "block";
//         rightA.style.display = "flex";
//         carouselB.scrollLeft += cardWidth + 20;
//         // console.log(carouselB.scrollLeft)
//     }
// })

// leftB.addEventListener("click", () => {
//     carouselB.classList.add("carousel-behavior-B");
//     if (carouselB.scrollLeft >= 1) {
//         leftA.style.display = "block";
//         leftA.style.display = "flex";
//         carouselB.scrollLeft += -(cardWidth + 20);
//         // console.log(carouselB.scrollLeft)
//     }
// })



// 14 footer-main-container

    // let footerHeadingDropDownA=document.querySelector('.footer-heading-dropDown-a')
    // let footerHeadingDropDownB=document.querySelector('.footer-heading-dropDown-b')
    // let footerHeadingDropDownC=document.querySelector('.footer-heading-dropDown-c')
    // let footerHeadingDropDownD=document.querySelector('.footer-heading-dropDown-d')

    // // 

    // let footerAllTextA=document.querySelector('.footer-all-text-a')
    // let footerAllTextB=document.querySelector('.footer-all-text-b')
    // let footerAllTextC=document.querySelector('.footer-all-text-c')
    // let footerAllTextD=document.querySelector('.footer-all-text-d')




    // footerHeadingDropDownA.addEventListener('click',()=>{
    //     footerAllTextA.classList.toggle('footer-heading-dropDown-toggle-a');
    //     console.log("clicked")
    // })

    // footerHeadingDropDownB.addEventListener('click',()=>{
    //     footerAllTextB.classList.toggle('footer-heading-dropDown-toggle-b');
    // })

    // footerHeadingDropDownC.addEventListener('click',()=>{
    //     footerAllTextC.classList.toggle('footer-heading-dropDown-toggle-c');
    // })

    // footerHeadingDropDownD.addEventListener('click',()=>{
    //     footerAllTextD.classList.toggle('footer-heading-dropDown-toggle-d');
    // })



    // 
    // 

    // let footersearchinput=document.getElementsByName('search')[0].placeholder='Enter y';
