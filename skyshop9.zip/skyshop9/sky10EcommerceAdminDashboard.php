<?php


session_start();

// $userLname=$_SESSION['userLpName'];
if (!isset($_SESSION['userLogin'])) {
    header('location:sky10EcommerceAdminLogin.php');
};

include 'sky9connect.php';


$PTitleErr = $PRPriceErr = $PFPriceErr = $TSelectionErr = $pdMainImgErr = "";
$Err = "";

$IPTitle = $IPRPrice = $IPFPrice = $ITSelection = $IpdImg2 = $IpdMainImg = "";

$requirement = true;

$clicked = false;

if (isset($_POST['submit'])) {

    $clicked = true;


    // PTitle validation
    if (empty($_POST['PTitle'])) {
        $PTitleErr = "Title is required";
        $requirement = false;
    } else {
        $PTitle = ucwords($_POST['PTitle']);
        $IPTitle = $PTitle;

        if (!preg_match("/^[a-zA-Z-' ]*$/", $PTitle)) {
            $PTitleErr = "Only letters allowed";
            $requirement = false;
        } elseif (strlen($PTitle) > 70) {
            $PTitleErr = "Tittle length allowed only less than 70 character";
            $requirement = false;
        } elseif (strlen($PTitle) < 3) {
            $PTitleErr = "Tittle length aloud greater than 2 character";
            $requirement = false;
        }
    }

    // PRPrice validation
    if (empty($_POST['PRPrice'])) {
        $PRPriceErr = "Price is required";
        $requirement = false;
    } else {
        $PRPrice = $_POST['PRPrice'];
        $IPRPrice = $PRPrice;

        if (!preg_match('/^[\d$₹]+$/', $PRPrice)) {
            $PRPriceErr = "Currency pattern invalid";
            $requirement = false;
        } elseif (strlen($PRPrice) > 5) {
            $PRPriceErr = "Price length allowed only less than 1e character";
            $requirement = false;
        } elseif (strlen($PRPrice) < 1) {
            $PRPriceErr = "Price length allowed greater than 0 character";
            $requirement = false;
        }
    }

    // PFPrice validation
    if (empty($_POST['PFPrice'])) {
        $PFPriceErr = "Price is required";
        $requirement = false;
    } else {
        $PFPrice = $_POST['PFPrice'];
        $IPFPrice = $PFPrice;

        if (!preg_match('/^[\d$₹]+$/', $PFPrice)) {
            $PFPriceErr = "Currency pattern invalid";
            $requirement = false;
        } elseif (strlen($PFPrice) > 5) {
            $PFPriceErr = "Price length allowed only less than 1 character";
            $requirement = false;
        } elseif (strlen($PFPrice) < 1) {
            $PFPriceErr = "Price length allowed greater than 0 character";
            $requirement = false;
        }
    }

    // tableSelection
    if (empty($_POST['tableSelection'])) {
        $TSelectionErr = "It's is required";
        $requirement = false;
    } else {
        $TSelection = $_POST['tableSelection'];
        $ITSelection = $TSelection;

        if (!preg_match('/^[\d]+$/', $TSelection)) {
            $TSelectionErr = "Only numbers allowed";
            $requirement = false;
        }
    }

    // pdImg2 validation
    if (isset($_FILES['pdImg2'])) {
        $file_name2 = $_FILES['pdImg2']['name'];
        $file_size2 = $_FILES['pdImg2']['size'];
        $file_tmp2 = $_FILES['pdImg2']['tmp_name'];
        $file_type2 = $_FILES['pdImg2']['type'];

        if (empty($file_name2)) {
            $pdImg2 = "";
        } else {
            if ($requirement) {
                move_uploaded_file($file_tmp2, "ecom/" . $file_name2);
            }
            $pdImg2 = 'Ecommerce/' . $file_name2;
            $IpdImg2 = $pdImg2;
        }
    }

    // pdImg3 validation
    if (isset($_FILES['pdImg3'])) {
        $file_name3 = $_FILES['pdImg3']['name'];
        $file_size3 = $_FILES['pdImg3']['size'];
        $file_tmp3 = $_FILES['pdImg3']['tmp_name'];
        $file_type3 = $_FILES['pdImg3']['type'];

        if (empty($file_name3)) {
            $pdImg3 = "";
        } else {
            if ($requirement) {
                move_uploaded_file($file_tmp3, "ecom/" . $file_name3);
            }
            $pdImg3 = 'Ecommerce/' . $file_name3;
            $IpdImg3 = $pdImg3;
        }
    }

    // pdImg4 validation
    if (isset($_FILES['pdImg4'])) {
        $file_name4 = $_FILES['pdImg4']['name'];
        $file_size4 = $_FILES['pdImg4']['size'];
        $file_tmp4 = $_FILES['pdImg4']['tmp_name'];
        $file_type4 = $_FILES['pdImg4']['type'];

        if (empty($file_name4)) {
            $pdImg4 = "";
        } else {
            if ($requirement) {
                move_uploaded_file($file_tmp4, "ecom/" . $file_name4);
            }
            $pdImg4 = 'Ecommerce/' . $file_name4;
            $IpdImg4 = $pdImg4;
        }
    }

    // pdImg5 validation
    if (isset($_FILES['pdImg5'])) {
        $file_name5 = $_FILES['pdImg5']['name'];
        $file_size5 = $_FILES['pdImg5']['size'];
        $file_tmp5 = $_FILES['pdImg5']['tmp_name'];
        $file_type5 = $_FILES['pdImg5']['type'];

        if (empty($file_name5)) {
            $pdImg5 = "";
        } else {
            if ($requirement) {
                move_uploaded_file($file_tmp5, "ecom/" . $file_name5);
            }
            $pdImg5 = 'Ecommerce/' . $file_name5;
            $IpdImg5 = $pdImg5;
        }
    }

    // pdImg6 validation
    if (isset($_FILES['pdImg6'])) {
        $file_name6 = $_FILES['pdImg6']['name'];
        $file_size6 = $_FILES['pdImg6']['size'];
        $file_tmp6 = $_FILES['pdImg6']['tmp_name'];
        $file_type6 = $_FILES['pdImg6']['type'];

        if (empty($file_name6)) {
            $pdImg6 = "";
        } else {
            if ($requirement) {
                move_uploaded_file($file_tmp6, "ecom/" . $file_name6);
            }
            $pdImg6 = 'Ecommerce/' . $file_name6;
            $IpdImg6 = $pdImg6;
        }
    }

    // pdMainImg validation
    if (isset($_FILES['pdMainImg'])) {

        $file_name = $_FILES['pdMainImg']['name'];
        $file_size = $_FILES['pdMainImg']['size'];
        $file_tmp = $_FILES['pdMainImg']['tmp_name'];
        $file_type = $_FILES['pdMainImg']['type'];

        if (empty($file_name)) {
            $pdMainImgErr = "Product image is required";
            $requirement = false;
        } else {
            if ($requirement) {
                move_uploaded_file($file_tmp, "ecom/" . $file_name);
            }
            $pdMainImg = 'Ecommerce/' . $file_name;
            $IpdMainImg = $pdMainImg;
        }
    }

    // $PTitle || $PRPrice || $PFPrice || $pdMainImg
    if (empty($PTitle) || empty($PRPrice) || empty($PFPrice) || empty($pdMainImg)) {
        $Err = "Please fill all requirement";
        $requirement = false;
    } elseif ($PTitle && $PRPrice && $PFPrice && $pdMainImg) {
        // $adminName = $_SESSION['userLogin'];
        if ($requirement) {

            // if ($TSelection === '1') {
                $MainImg = "SELECT * FROM weballproducts WHERE CLICKIMG='$pdMainImg'";
            // } elseif ($TSelection === '2') {
            //     $MainImg = "SELECT * FROM weballproductsb WHERE CLICKIMG='$pdMainImg'";
            // }

            // $Passma = "SELECT * FROM adminaddeda WHERE Password='$pass'";

            $query2 = mysqli_query($con, $MainImg);
            // $query3 = mysqli_query($con, $Passma);

            $row2 = mysqli_fetch_array($query2);
            // $row3 = mysqli_fetch_array($query3);
        }



        if (isset($row2)) {
            $pdMainImgErr = "Image is already exist";
        } elseif ($requirement) {

            // if ($TSelection === '1') {
                $sql = "INSERT INTO weballproducts(CLICKIMG,PDIMG1,PDIMG2,PDIMG3,PDIMG4,PDIMG5,PDIMG6,Product_Title,PReal_Price,PFULL_Price,Product_Code) VALUES ('$pdMainImg','$pdMainImg','$pdImg2','$pdImg3','$pdImg4','$pdImg5','$pdImg6','$PTitle','$PRPrice','$PFPrice','$TSelection')";
            // } elseif ($TSelection === '2') {
            //     $sql = "INSERT INTO weballproductsb(CLICKIMG,PDIMG1,PDIMG2,PDIMG3,PDIMG4,PDIMG5,PDIMG6,Product_Title,PReal_Price,PFULL_Price) VALUES ('$pdMainImg','$pdMainImg','$pdImg2','$pdImg3','$pdImg4','$pdImg5','$pdImg6','$PTitle','$PRPrice','$PFPrice')";
            // }


            $query = mysqli_query($con, $sql);

            if ($query) {
                $IPTitle = $IPRPrice = $IPFPrice = $IpdImg2 = $IpdMainImg = "";

                // echo "data inserted successful";
                // header('location:sky12AdminDashboard.php');
            } else {
                echo "data not inserted successful";
                // die(mysqli_error($con));
            }
        }
    }
}


?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ecommerce Admin Dashboard</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" />

    <link rel="stylesheet" href="sky10EcommerceAdmin.css">

</head>

<body>

    <div class="container">
        <div class="container-b">

            <div class="dashboard-main-container">
                <div class="dashboard-header">
                    <p class="dashboard-text">Dashboard</p>
                    <input class="search-input" type="text" placeholder="Search">

                    <div class="admin-profile-box">
                        <div class="admin-img">
                            <i class="fa-regular fa-user"></i>
                        </div>
                        <p class="admin-name">
                            <?php echo $_SESSION['userLogin'];
                            echo '&nbsp';
                            echo $_SESSION['userLName'] ?>
                        </p>
                    </div>

                </div>

                <div class="dashboard-center">

                    <div class="dashboard-options">

                        <div class="dashboard-option-box dashboard-option-box-a">
                            <div class="desktop-text-icon-box">
                                <i class="fa-solid fa-house"></i>
                                <p>Home</p>

                            </div>
                            <p>></p>

                        </div>


                        <div class="dashboard-option-box dashboard-option-box-b">

                            <div class="desktop-text-icon-box">
                                <i class="fa-regular fa-user"></i>
                                <p>Profile</p>
                            </div>

                            <p>></p>

                        </div>

                        <div class="dashboard-option-box dashboard-option-box-c">
                            <div class="desktop-text-icon-box">
                                <i class="fa-solid fa-plus"></i>
                                <p>Add More</p>
                            </div>
                            <p>></p>

                        </div>

                        <div class="dashboard-option-box dashboard-option-box-c" onclick="window.location.href='sky10EcommerceAdminLogout.php'">
                            <div class="desktop-text-icon-box">
                                <i class="fa-solid fa-right-from-bracket"></i>
                                <p>Logout</p>

                            </div>
                            <p>></p>

                        </div>

                        <div class="dashboard-option-box dashboard-option-box-d">
                            <div class="desktop-text-icon-box"></div>

                        </div>

                        <div class="dashboard-option-box dashboard-option-box-e">
                            <div class="desktop-text-icon-box"></div>

                        </div>

                        <div class="dashboard-option-box dashboard-option-box-f">
                            <div class="desktop-text-icon-box"></div>

                        </div>

                    </div>

                    <div class="dashboard-admin-all-container">

                        <div class="added-people-by-admin">

                            <div class="dashboard-new-and-top-products-con">
                                <div class="top-picks-box" value="1">
                                    <p value="">Top Picks</p>
                                </div>

                                <div class="new-arrivals-box" value="2">
                                    <p>New Arrivals</p>
                                </div>
                            </div>

                            <table border="1px" cellspacing="0" class="added-people-by-admin-tbl">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Main Product</th>
                                        <th>Related 1</th>
                                        <th>Related 2</th>
                                        <th>Related 3</th>
                                        <th>Related 4</th>
                                        <th>Related 5</th>
                                        <th>Related 6</th>
                                        <th>Tittle</th>
                                        <th>Real Price</th>
                                        <th>Full Price</th>
                                        <th>Product Code</th>



                                        <th class="action">Action</th>
                                    </tr>

                                </thead>
                                <tbody class="admin-dashboard-table-Body">

                                </tbody>
                                <tfoot></tfoot>
                            </table>
                        </div>

                        <div class="add-more-option-form">
                            <form class="add-more-form" action="" method="post" enctype="multipart/form-data">
                                <h1 class="add-more-action-name">Add More Products</h1>

                                <div class="add-more-FLname">
                                    <div class="add-more-Fname">
                                        <input class="add-input input-fname" type="text" name="PTitle" id="" placeholder="Enter product title" value="<?php echo $IPTitle ?>">
                                        <span class="err errA"><?php echo $PTitleErr ?></span>

                                    </div>

                                    <div class="add-more-Lname">
                                        <input class="add-input input-lname" type="text" name="PRPrice" id="" placeholder="Enter real price" value="<?php echo $IPRPrice ?>">
                                        <span class="err errB"><?php echo $PRPriceErr ?></span>

                                    </div>

                                </div>

                                <div class="add-more-EN">
                                    <div class="add-more-email">
                                        <input class="add-input input-email" type="text" name="PFPrice" id="" placeholder="Enter full price" value="<?php echo $IPFPrice ?>">
                                        <span class="err errC"><?php echo $PFPriceErr ?></span>

                                    </div>

                                    <div class="add-more-number">
                                        <select class="add-input add-more-table-selection" name="tableSelection" id="">
                                            <option value="1">Top Picks</option>
                                            <option value="2">New Arrivals</option>
                                        </select>

                                        <span class="err errD"><?php echo $TSelectionErr  ?></span>
                                    </div>


                                </div>

                                <!--  -->

                                <div class="add-more-PD12">
                                    <div class="add-more-PD1">
                                        <input class="product-detail-file-input" type="file" name="pdMainImg" accept="image/*" id="product-detail-file-input" value="<?php echo $IPFPrice ?>">
                                        <label class="product-detail-file-input-label" for="product-detail-file-input"><span class="product-detail-label-span">No file chosen</span>
                                            <div class="product-detail-file-input2">
                                                <i class="fa-solid fa-cloud-arrow-up"></i> Upload image
                                            </div>
                                        </label>

                                        <span class="err errE"><?php echo $pdMainImgErr ?></span>
                                    </div>

                                    <!--  -->

                                    <input class="product-detail-IMG2 img-file-input" type="file" name="pdImg2" accept="image/*" id="product-detail-IMG2">
                                    <label class="product-detail-IMG2-label file-img-label" for="product-detail-IMG2"><span class="product-detail-label-span-IMG2">No file chosen</span>
                                        <div class="product-detail-file-input2">
                                            <i class="fa-solid fa-cloud-arrow-up"></i> Upload image
                                        </div>
                                    </label>

                                </div>

                                <div class="add-more-PD34">
                                    <input class="product-detail-IMG3 img-file-input" type="file" name="pdImg3" accept="image/*" id="product-detail-IMG3">
                                    <label class="product-detail-IMG3-label file-img-label" for="product-detail-IMG3"><span class="product-detail-label-span-IMG3">No file chosen</span>
                                        <div class="product-detail-file-input2">
                                            <i class="fa-solid fa-cloud-arrow-up"></i> Upload image
                                        </div>
                                    </label>

                                    <!--  -->

                                    <input class="product-detail-IMG4 img-file-input" type="file" name="pdImg4" accept="image/*" id="product-detail-IMG4">
                                    <label class="product-detail-IMG4-label file-img-label" for="product-detail-IMG4"><span class="product-detail-label-span-IMG4">No file chosen</span>
                                        <div class="product-detail-file-input2">
                                            <i class="fa-solid fa-cloud-arrow-up"></i> Upload image
                                        </div>
                                    </label>
                                </div>

                                <div class="add-more-PD56">
                                    <input class="product-detail-IMG5 img-file-input" type="file" name="pdImg5" accept="image/*" id="product-detail-IMG5">
                                    <label class="product-detail-IMG5-label file-img-label" for="product-detail-IMG5"><span class="product-detail-label-span-IMG5">No file chosen</span>
                                        <div class="product-detail-file-input2">
                                            <i class="fa-solid fa-cloud-arrow-up"></i> Upload image
                                        </div>
                                    </label>

                                    <!--  -->

                                    <input class="product-detail-IMG6 img-file-input" type="file" name="pdImg6" accept="image/*" id="product-detail-IMG6">
                                    <label class="product-detail-IMG6-label file-img-label" for="product-detail-IMG6"><span class="product-detail-label-span-IMG6">No file chosen</span>
                                        <div class="product-detail-file-input2">
                                            <i class="fa-solid fa-cloud-arrow-up"></i> Upload image
                                        </div>
                                    </label>
                                </div>

                                <!--  -->



                                <input class="add-submit" name="submit" type="submit" value="SUBMIT">

                            </form>


                        </div>

                        <div class="admin-profile-page">

                            <div class="admin-profile-box-container">
                                <div class="admin-img-name-box">
                                    <i class="admin-profile-img fa-regular fa-user"></i>

                                    <p class="admin-full-name"><?php echo $_SESSION['userLogin'];
                                                                echo '&nbsp';
                                                                echo $_SESSION['userLName'];    ?></p>
                                </div>

                                <div class="admin-email-password-main-box">

                                    <div class="admin-email-box">
                                        <p class="admin-email-text">Email :</p>
                                        <p class="admin-email"><?php echo $_SESSION['userEmail']; ?></p>
                                    </div>
                                    <div class="admin-password-box">
                                        <p class="admin-password-text">Password :</p>
                                        <p class="admin-password"><?php echo $_SESSION['userPassword']; ?></p>
                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </div>


        </div>
    </div>

    <script type="text/javascript" src="jquery.min.js"></script>

    <script>
        let homeBoxClickedOrNot = false;
        let AddMoreClickedOrNot = false;
        document.querySelector('.dashboard-option-box-a').addEventListener('click', () => {
            document.querySelector('.added-people-by-admin').style.display = 'block';
            document.querySelector('.add-more-option-form').style.display = 'none';
            document.querySelector('.admin-profile-page').style.display = 'none';

        })

        document.querySelector('.dashboard-option-box-c').addEventListener('click', () => {
            document.querySelector('.added-people-by-admin').style.display = 'none';
            document.querySelector('.add-more-option-form').style.display = 'block';
            document.querySelector('.admin-profile-page').style.display = 'none';

        })

        document.querySelector('.dashboard-option-box-b').addEventListener('click', () => {
            document.querySelector('.added-people-by-admin').style.display = 'none';
            document.querySelector('.add-more-option-form').style.display = 'none';
            document.querySelector('.admin-profile-page').style.display = 'block';
            document.querySelector('.admin-profile-page').style.display = 'flex';


        })

        // dashboard-new-and-top-products-con
        
        document.querySelector('.top-picks-box').addEventListener('click', () => {
            document.querySelector('.top-picks-box').style.backgroundColor = 'blue';
            document.querySelector('.top-picks-box').style.color = 'white';
            document.querySelector('.new-arrivals-box').style.backgroundColor = 'white';
            document.querySelector('.new-arrivals-box').style.color = 'black';
            
            let topPickVal=document.querySelector('.top-picks-box').getAttribute('value');
            tableLoad(topPickVal, "", "");
        })

        document.querySelector('.new-arrivals-box').addEventListener('click', () => {
            document.querySelector('.new-arrivals-box').style.backgroundColor = 'blue';
            document.querySelector('.new-arrivals-box').style.color = 'white';
            document.querySelector('.top-picks-box').style.backgroundColor = 'white';
            document.querySelector('.top-picks-box').style.color = 'black';

            let newArrivalsVal=document.querySelector('.new-arrivals-box').getAttribute('value');
            tableLoad(newArrivalsVal, "", "");
            // console.log(newArrivalsVal)
        })

        let submitOrNot = '<?php echo $clicked; ?>';

        if (submitOrNot) {
            document.querySelector('.added-people-by-admin').style.display = 'none';
            document.querySelector('.add-more-option-form').style.display = 'block';
        }

        // table by added by admin
        // admin suneel
        let adminName = '<?php echo $_SESSION['userLogin']; ?>';

        if (adminName === 'Suneel') {
            $(document).ready(function() {
            let topPickVal2=document.querySelector('.top-picks-box').getAttribute('value');
                tableLoad(topPickVal2, "", "");
            })
        } else if (adminName === 'Aman') {
            let topPickVal2=document.querySelector('.top-picks-box').getAttribute('value');
            $(document).ready(function() {
                tableLoad(topPickVal2, "", "");
            })
        }


        // first Admin Function
        function tableLoad(loadTable, personID, userSearch) {
            $.ajax({
                url: "sky10EcommerceAdminDB.php",
                type: "POST",
                dataType: "JSON",
                data: {
                    productTableCode: loadTable,
                    deleteID: personID,
                    userSearchData: userSearch
                },
                success: function(data) {
                    let adminTableData = "";
                    $.each(data, function(key, value) {

                        adminTableData += `<tr>
                                        <td>${value.ID}</td>
                                        <td>${value.CLICKIMG}</td>
                                        <td>${value.PDIMG1}</td>
                                        <td>${value.PDIMG2}</td>
                                        <td>${value.PDIMG3}</td>
                                        <td>${value.PDIMG4}</td>
                                        <td>${value.PDIMG5}</td>
                                        <td>${value.PDIMG6}</td>
                                        <td>${value.Product_Title}</td>
                                        <td>${value.PReal_Price}</td>
                                        <td>${value.PFULL_Price}</td>
                                        <td>${value.Product_Code}</td>


                                        <td class="action-btn"><button class="delete-btn" onclick="personID(${value.ID})">DELETE</button>
                                        <button class="update-btn" onclick="window.location.href='sky10EcommerceAdminUpdate.php?pUpdateId=${value.ID}'">UPDATE</button></td>
                                    </tr>`;
                    })

                    $('.admin-dashboard-table-Body').html("")
                    $('.admin-dashboard-table-Body').append(adminTableData)
                }
            })
        }

        // onclick="window.location.href='sky12AdminDashboard.php?pUpdateId=${value.ID}'
        // delete function

        function personID(personID) {
            if (confirm('Are you want to delete this user?')) {

                tableLoad('', personID);
                console.log(personID);
            }
        }



        // // // // // // // // //
        // second admin function 
        // function tableBLoadB(adminB, personIDB, userSearchB) {
        //     $.ajax({
        //         url: "sky10EcommerceAdminDB.php",
        //         type: "POST",
        //         dataType: "JSON",
        //         data: {
        //             secondAdmin: adminB,
        //             deleteIDB: personIDB,
        //             userSearchDataB: userSearchB
        //         },
        //         success: function(data) {
        //             let adminTableDataB = "";
        //             $.each(data, function(key, value) {

        //                 adminTableDataB += `<tr>
        //                 <td>${value.ID}</td>
        //                                 <td>${value.CLICKIMG}</td>
        //                                 <td>${value.PDIMG1}</td>
        //                                 <td>${value.PDIMG2}</td>
        //                                 <td>${value.PDIMG3}</td>
        //                                 <td>${value.PDIMG4}</td>
        //                                 <td>${value.PDIMG5}</td>
        //                                 <td>${value.PDIMG6}</td>
        //                                 <td>${value.Product_Title}</td>
        //                                 <td>${value.PReal_Price}</td>
        //                                 <td>${value.PFULL_Price}</td>
        //                                 <td class="action-btn"><button class="delete-btn" onclick="personIDB(${value.ID})">DELETE</button>
        //                                 <button class="update-btn" onclick="window.location.href='sky10EcommerceAdminUpdate.php?pUpdateId=${value.ID}'">UPDATE</button></td>
        //                             </tr>`;
        //             })

        //             $('.admin-dashboard-table-Body').html("")
        //             $('.admin-dashboard-table-Body').append(adminTableDataB)
        //         }
        //     })
        // }

        // // delete function B
        // function personIDB(personIDB) {
        //     if (confirm('Are you want to delete this user?')) {

        //         console.log(personIDB);
        //         tableBLoadB('', personIDB);
        //     }
        // }

        // search filter function
        $('.dashboard-header .search-input').keyup(function() {
            // console.log($(this).val());
            if (adminName === 'aman') {
                tableBLoadB('', '', $(this).val());
            };

            if (adminName === 'suneel') {
                tableLoad('', '', $(this).val());
            };
        });

        // add more input
        $('.input-fname').on('keyup', function() {
            var ii = $(this).val();
            $('.errA').html("");
            // $('.errTop').html("")
        })

        $('.input-lname').on('keyup', function() {
            var ii = $(this).val();
            $('.errB').html("");
            // $('.errTop').html("")
        })

        $('.input-email').on('keyup', function() {
            var ii = $(this).val();
            $('.errC').html("");
            // $('.errTop').html("")
        })

        $('.input-phone').on('keyup', function() {
            var ii = $(this).val();
            $('.errD').html("");
            // $('.errTop').html("")
        })

        $('.add-city').on('keyup', function() {
            var ii = $(this).val();
            $('.errE').html("");
            // $('.errTop').html("")
        })

        $('.add-date').on('keyup', function() {
            var ii = $(this).val();
            $('.errF').html("");
            // $('.errTop').html("")
        })

        $('.input-address').on('keyup', function() {
            var ii = $(this).val();
            $('.errG').html("");
            // $('.errTop').html("")
        })


        // img file selection database
        // main img 
        document.getElementById('product-detail-file-input').addEventListener('change', function() {
            var fileName = this.value.split('\\').pop();
            // console.log(fileName);
            document.querySelector('.product-detail-label-span').innerText = fileName || 'No file chosen';
        });

        // 2 img 
        document.getElementById('product-detail-IMG2').addEventListener('change', function() {
            var fileName = this.value.split('\\').pop();
            // console.log(fileName);
            document.querySelector('.product-detail-label-span-IMG2').innerText = fileName || 'No file chosen';
        });

        // 3 img 
        document.getElementById('product-detail-IMG3').addEventListener('change', function() {
            var fileName = this.value.split('\\').pop();
            // console.log(fileName);
            document.querySelector('.product-detail-label-span-IMG3').innerText = fileName || 'No file chosen';
        });

        // 4 img 
        document.getElementById('product-detail-IMG4').addEventListener('change', function() {
            var fileName = this.value.split('\\').pop();
            // console.log(fileName);
            document.querySelector('.product-detail-label-span-IMG4').innerText = fileName || 'No file chosen';
        });

        // 5 img 
        document.getElementById('product-detail-IMG5').addEventListener('change', function() {
            var fileName = this.value.split('\\').pop();
            // console.log(fileName);
            document.querySelector('.product-detail-label-span-IMG5').innerText = fileName || 'No file chosen';
        });

        // 6 img 
        document.getElementById('product-detail-IMG6').addEventListener('change', function() {
            var fileName = this.value.split('\\').pop();
            // console.log(fileName);
            document.querySelector('.product-detail-label-span-IMG6').innerText = fileName || 'No file chosen';
        });

    </script>



</body>

</html>