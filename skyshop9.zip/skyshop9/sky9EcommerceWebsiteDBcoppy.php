<?php

// database connection
$con = mysqli_connect("localhost", "root", "", "skyphp") or die("connection failed");

// check data is coming or not empty
$resentViewData=false;
if (isset($_POST['resentViewData']) && !empty($_POST['resentViewData'])) {
    $resentViewData=true;
}
if (isset($_POST['recentViewImg']) && !empty($_POST['recentViewImg'])) {

    $recentViewImg = $_POST['recentViewImg'];

    // check product already exist or not
    $sql2 = "SELECT * FROM `webrecentviewe` WHERE IMG='$recentViewImg'";
    $query2 = mysqli_query($con, $sql2);
    $row = mysqli_fetch_array($query2);


    if (!$row) {                      //if data does'nt exist
        $sql3 = "INSERT INTO `webrecentviewe`(IMG) VALUES('$recentViewImg')";
        $query3 = mysqli_query($con, $sql3);
    } else {                           //if data exists then delete the data and insert in the last

    };
};


if (isset($_POST['clear']) && !empty($_POST['clear'])) {
    $sql4 = 'TRUNCATE TABLE webrecentviewe';
    $query4 = mysqli_query($con, $sql4);


    $sql = "SELECT * FROM `webrecentviewe`";
    $query = mysqli_query($con, $sql);

    $result = mysqli_fetch_all($query, MYSQLI_ASSOC);

    echo json_encode($result);
} else {
    $sql = "SELECT * FROM `webrecentviewe`";
    $query = mysqli_query($con, $sql);

    $result = mysqli_fetch_all($query, MYSQLI_ASSOC);


    if($resentViewData){
        echo json_encode($result);
    }
}






// 
// 



if (isset($_POST['recentViewImg']) && !empty($_POST['recentViewImg'])) {
}