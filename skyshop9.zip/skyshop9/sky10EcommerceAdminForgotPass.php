<?php

session_start();

if (isset($_SESSION['userLogin'])) {
    header('location:sky10EcommerceAdminDashboard.php');
};

include 'sky9connect.php';


$emailerr = "";
$IEmail = "";
$requirement = true;
$Err = "";

if (isset($_POST['submit'])) {

    // Email validation
    if (empty($_POST['email'])) {
        $emailerr = "Email is required";
        $requirement = false;
    } else {
        $email = $_POST['email'];
        $IEmail = $email;

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $emailerr = "Invalid email format";
            $requirement = false;
        }
    }


    if ($requirement) {

        $sql = "SELECT * FROM webadmintable WHERE Email='$email'";
        $query = mysqli_query($con, $sql);
        // $row=mysqli_fetch_array($query);

        if ($query) {
            if ($row = mysqli_fetch_assoc($query)) {
                $_SESSION['userEmail'] = $row['Email'];

                // header('location:sky9webphpmailer.php');
                header('location:sky10EcommerceAdminPassOTP.php');

            } else {
                $Err = "Invalid email";
            }
        }
    }
}

?>









<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Forgot Password Form</title>

    <link rel="stylesheet" href="sky10EcommerceAdmin.css">
    <script type="text/javascript" src="jquery.min.js"></script>

</head>

<body>
    <div class="reg">
        <div class="form-con">
            <form action="" method="POST">
                <h1 class="login-text">Forgot Password</h1>
                <span class="err"><?php echo $Err;   ?></span>

                <input class="inp" type="text" name="email" placeholder="Enter your email" value="<?php echo $IEmail;   ?>">
                <span class="err"><?php echo $emailerr;   ?></span>

                <input class="btn" name="submit" type="submit" value="Continue">
            </form>
        </div>

        <div class="already-register">
            <p>Don't have an account <a href="sky10EcommerceAdminRegister.php">Register</a>
            </p>
        </div>
    </div>


    <script>

        $('.btn').click((e)=>{
            // console.log('triggered');
            forgotPass('Forget');
        })

        function forgotPass(FPData) {

            $.ajax({
                url:'sky9webphpmailer.php',
                type:'POST',
                dataType:'JSON',
                data:{
                    forgotP:FPData
                }
            })
        }
    </script>
</body>

</html>