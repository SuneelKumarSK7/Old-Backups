<?php
include 'sky9connect.php';
session_start();
$email=$_SESSION['userEmail'];

//Import PHPMailer classes into the global namespace
//These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

//Load Composer's autoloader
require 'src/Exception.php';
require 'src/PHPMailer.php';
require 'src/SMTP.php';

//Create an instance; passing `true` enables exceptions
$mail = new PHPMailer(true);
$randomNum=mt_rand(1000,9999);

$requirement = true;

if(isset($_POST['forgotP']) && !empty($_POST['forgotP'])){
// // // //

    try {
        //Server settings
        $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
        $mail->isSMTP();                                            //Send using SMTP
        $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
        $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
        $mail->Username   = 'daklongaming77@gmail.com';                     //SMTP username
        $mail->Password   = 'doatutmocjtowbyc';                               //SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;            //Enable implicit TLS encryption
        $mail->Port       = 587;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
    
        //Recipients
        $mail->setFrom('daklongaming77@gmail.com', 'SKYShop');
        $mail->addAddress($email, 'Customer');     //Add a recipient
        // $mail->addAddress('ellen@example.com');               //Name is optional
        $mail->addReplyTo('daklongaming77@gmail.com', 'SKYShop');
        // $mail->addCC('cc@example.com');
        // $mail->addBCC('bcc@example.com');
    
        //Attachments
        // $mail->addAttachment('/var/tmp/file.tar.gz');         //Add attachments
        // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    //Optional name
    
        //Content
        $mail->isHTML(true);                                  //Set email format to HTML
        $mail->Subject = 'This is your OTP';
        $mail->Body    = 'Hello this is your valid OTP '.'<b>'.$randomNum.'</b>';
        $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
    
        $mail->send();
        if($requirement){
            
            $sql="UPDATE webadmintable SET OTP =$randomNum  WHERE Email='$email'";
            $query=mysqli_query($con,$sql);
    
            if ($query) {
                $_SESSION['check']='check';
                $_SESSION['check2']='check2';
    
                
                // echo '<script>window.location.href = "sky10EcommerceAdminPassOTP.php";</script>';
                echo 'Message has been sent';
            }else{
                echo 'Something went wrong';
            }
    
    
        }
        
    
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        $requirement = false;
    };

// // // //
}else{
    echo 'something went wrong';
}





?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Web PHP Mailer</title>
</head>
<body>
    
</body>
</html>
