<?php
include 'sky9connect.php';


$passErr = $RPassErr = "";
$Err = "";
$IPsword = $IRPass = "";
$requirement = true;

if (isset($_POST['submit'])) {

    // Password validation
    // {8,10}$
    if (empty($_POST['pass'])) {
        $passErr = "Password is required";
        $requirement = false;
    } else {
        $pass = $_POST['pass'];
        $IPsword = $pass;

        if (!preg_match("^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]^", $pass)) {
            $passErr = "At least one upper, lower case, number, special charector ";
            $requirement = false;
        } elseif (strlen($pass) > 10) {
            $passErr = "Password length allowd only less than 10 charector ";
            $requirement = false;
        } elseif (strlen($pass) < 4) {
            $passErr = "Password allowd atleast 4 charector";
            $requirement = false;
        }
    }

    // Reenter Password validation
    if (empty($_POST['RPass'])) {
        $RPassErr = "Password is required";
        $requirement = false;
    } else {
        $RPass = $_POST['RPass'];
        $IRPass = $RPass;

        if (!preg_match("^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]^", $pass)) {
            $RPassErr = "At least one upper, lower case, number, special charector ";
            $requirement = false;
        } elseif (strlen($pass) > 10) {
            $RPassErr = "Password length allowd only less than 10 charector ";
            $requirement = false;
        } elseif (strlen($pass) < 4) {
            $RPassErr = "Password allowd atleast 4 charector";
            $requirement = false;
        }
    }


    // $fname || $lname || $email || $pass
    if (empty($RPass) || empty($pass)) {
        $Err = "Please fill all requirement";
        $requirement = false;
    } elseif ($RPass && $pass) {

        if ($RPass !== $pass) {
            $Err = "Password is not matching";
            $requirement = false;
        } else {
            session_start();
            $email=$_SESSION['userEmail'];
            $sql = "UPDATE webadmintable SET Password ='$pass' WHERE Email='$email'";

            $query=mysqli_query($con,$sql);

            if($query){
                header('location:sky10EcommerceAdminLogin.php');
            }
        }
    }
}



?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Change Password</title>
    <link rel="stylesheet" href="sky10EcommerceAdmin.css">
</head>

<body>
    <div class="reg">
        <div class="form-con">
            <form action="" method="POST">
                <h1 class="register-text">Change Password</h1>
                <span class="err errTop"><?php echo $Err;   ?></span>

                <input class="inp inp-D" type="text" name="pass" placeholder="Password" value="<?php echo $IPsword;   ?>">
                <span class="err errD"><?php echo $passErr;   ?></span>

                <input class="inp inp-D" type="text" name="RPass" placeholder="Reenter Password" value="<?php echo $IRPass;   ?>">
                <span class="err errD"><?php echo $RPassErr;   ?></span>

                <input class="btn" name="submit" type="submit" value="SUBMIT">
            </form>
        </div>

        <div class="already-register">
            <p>Already have registered <a href="sky10EcommerceAdminLogin.php">click here</a>
            </p>
        </div>
    </div>



    <script type="text/javascript" src="jquery.min.js"></script>


    <!-- <script>
        
        $('.inp-A').on('keyup', function() {
            var ii = $(this).val()
            // console.log(ii)
            $('.errA').html("")
            $('.errTop').html("")

        })

        $('.inp-B').on('keyup', function() {
            var ii = $(this).val()
            // console.log(ii)
            $('.errB').html("")
            $('.errTop').html("")
        })

        $('.inp-C').on('keyup', function() {
            var ii = $(this).val()
            // console.log(ii)
            $('.errC').html("")
            $('.errTop').html("")
        })

        $('.inp-D').on('keyup', function() {
            var ii = $(this).val()
            // console.log(ii)
            $('.errD').html("")
            $('.errTop').html("")
        })
    </script> -->


</body>

</html>