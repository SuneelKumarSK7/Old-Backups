<?php
session_start();
include 'sky9connect.php';

if (isset($_POST['productTableCode']) and !empty($_POST['productTableCode'])) {

    $productCode=$_POST['productTableCode'];
    // $sql2 = "SELECT * FROM `weballproducts`";
    $sql2="SELECT * FROM `weballproducts` WHERE Product_Code=$productCode";

    $query2 = mysqli_query($con, $sql2) or die('Something went wrong');
    // $row=mysqli_num_rows($query2);
    // if($row < 1){
    //     $sql3="TRUNCATE TABLE weballproducts";
    //     $query3 = mysqli_query($con, $sql3) or die('Table is not delete');
    // }

    // $sql = "SELECT * FROM `weballproducts`";
    $sql="SELECT * FROM `weballproducts` WHERE Product_Code=$productCode";


    $_SESSION['tableCode'] = $productCode;
} elseif (isset($_POST['deleteID']) and !empty($_POST['deleteID'])) {
    $personID = $_POST['deleteID'];

    $sql2 = "DELETE FROM weballproducts WHERE ID=$personID";
    $query2 = mysqli_query($con, $sql2) or die('data is not delete');

    $sql = "SELECT * FROM `weballproducts`";
} elseif (isset($_POST['userSearchData']) and !empty($_POST['userSearchData'])) {
    $userSearchData = $_POST['userSearchData'];
    $sql = "SELECT * FROM `adminaddeda` WHERE First_Name LIKE '%$userSearchData%' OR Last_Name LIKE '%$userSearchData%' OR Email LIKE '%$userSearchData%' OR Phone LIKE '%$userSearchData%' OR City LIKE '%$userSearchData%' OR Date LIKE '%$userSearchData%' OR Address LIKE '%$userSearchData%'";
} elseif (isset($_POST['userSearchData']) and empty($_POST['userSearchData'])) {
    $sql = "SELECT * FROM `adminaddeda`";
} elseif (isset($_POST['secondAdmin']) and !empty($_POST['secondAdmin'])) {
    $sql2 = "SELECT * FROM `weballproductsb`";
    $query2 = mysqli_query($con, $sql2) or die('Something went wrong');
    $row=mysqli_num_rows($query2);
    if($row < 1){
        $sql3="TRUNCATE TABLE weballproductsb";
        $query3 = mysqli_query($con, $sql3) or die('Table is not delete');
    }


    $sql = "SELECT * FROM `weballproductsb`";

    $_SESSION['tableCode'] = '2';
} elseif (isset($_POST['deleteIDB']) and !empty($_POST['deleteIDB'])) {
    $personID = $_POST['deleteIDB'];

    $sql2 = "DELETE FROM weballproductsb WHERE ID=$personID";
    $query2 = mysqli_query($con, $sql2) or die('data is not delete');

    $sql = "SELECT * FROM `weballproductsb`";
} elseif (isset($_POST['userSearchDataB']) and !empty($_POST['userSearchDataB'])) {
    $userSearchData = $_POST['userSearchDataB'];

    $sql = "SELECT * FROM `adminaddedb` WHERE First_Name LIKE '%$userSearchData%' OR Last_Name LIKE '%$userSearchData%' OR Email LIKE '%$userSearchData%' OR Phone LIKE '%$userSearchData%' OR City LIKE '%$userSearchData%' OR Date LIKE '%$userSearchData%' OR Address LIKE '%$userSearchData%'";
} elseif (isset($_POST['userSearchDataB']) and empty($_POST['userSearchDataB'])) {
    $sql = "SELECT * FROM `adminaddedb`";
} elseif (isset($_POST['deleteEmail']) and !empty($_POST['deleteEmail']) and isset($_POST['unsetCheck']) and !empty($_POST['unsetCheck'])) {
    $deleteEmail = $_POST['deleteEmail'];
    $sqlB = "UPDATE webadmintable SET OTP =NULL WHERE Email='$deleteEmail'";
    $query = mysqli_query($con, $sqlB);

    if (!$query) {
        echo "Query failed";
    }
    session_start();
    unset($_SESSION['check']);
} elseif (isset($_POST['unsetCheck2']) and !empty($_POST['unsetCheck2'])) {
    session_start();
    unset($_SESSION['check2']);
}


$query = mysqli_query($con, $sql);

$result = mysqli_fetch_all($query, MYSQLI_ASSOC);

echo json_encode($result);



// $sql2 = "SELECT * FROM weballproducts WHERE ID=1";
// $query2 = mysqli_query($con, $sql2) or die('data is not delete');

// if($query2){
//     while($row=mysqli_fetch_assoc($query2)){
//         $a=$row['CLICKIMG'];
//         $b=$row['PDIMG1'];
//         $c=$row['PDIMG2'];
//         $d=$row['PDIMG3'];
//         $e=$row['PDIMG4'];
//         $f=$row['PDIMG5'];
//         $g=$row['PDIMG6'];

//     }
// }

// echo $a. $b. $c. $d. $e. $f. $g;

// $file_path = 'ecom/T-Sirt-17.avif';

// // Check if the file exists before attempting to delete it
// if (file_exists($file_path)) {
//     // Attempt to delete the file
//     if (unlink($file_path)) {
//         echo 'File deleted successfully.';
//     } else {
//         echo 'Unable to delete the file.';
//     }
// } else {
//     echo 'File does not exist.';
// }