<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wishlist Products</title>


    <!--  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" />
    <!--  -->

    <link rel="stylesheet" href="sky9EcommerceWebsite.css">

    <script type="text/javascript" src="jquery.min.js"></script>
</head>

<body>


    <div id="main-container">
        <div id="container">


            <!-- desktop menu container -->
            <div id="desktop-menu-container">
                <div id="desktop-menubar-container">

                    <div id="desktop-header-box">

                        <div id="desktop-text">

                            <div class="desktop-country-currency">

                                <p id="desktop-country" class="paragraph">United States (USD $) </p>
                                <i id="country-currency-downIcon" class="fa-solid fa-chevron-down desktop-downIcon"></i>


                                <div class="currency-section-dropdown">
                                    <ul>
                                        <li class="currency-dropdown-text"><a class="paragraph" href="">France (EUR
                                                &#8364)</a></li>
                                        <li class="currency-dropdown-text"><a class="paragraph" href="">Japan (JPY
                                                &#165)</a></li>
                                        <li class="currency-dropdown-text"><a class="paragraph" href="">Netherland (USD
                                                $)</a></li>
                                        <li class="currency-dropdown-text"><a class="paragraph" href="">United Kingdom
                                                (GBP &#163)</a></li>
                                        <li class="currency-dropdown-text"><a class="paragraph" href="">United State
                                                (USD $)</a></li>

                                    </ul>
                                </div>

                            </div>

                            <div class="desktop-country-language">
                                <p id="desktop-language" class="paragraph">English </p>
                                <i id="country-language-downIcon" class="fa-solid fa-chevron-down desktop-downIcon"></i>

                                <div class="language-section-dropdown">
                                    <ul>
                                        <li class="language-dropdown-text"><a class="paragraph" href="">English</a></li>
                                        <li class="language-dropdown-text"><a class="paragraph" href="">Hindi</a></li>
                                        <li class="language-dropdown-text"><a class="paragraph" href="">Netherland</a>
                                        </li>
                                        <li class="language-dropdown-text"><a class="paragraph" href="">Français</a>
                                        </li>
                                        <li class="language-dropdown-text"><a class="paragraph" href="">日本語</a></li>

                                    </ul>
                                </div>
                            </div>

                        </div>

                        <div class="menu-btn-container">

                            <div id="menubar">
                                <i id="menu-icon" class="fa-solid fa-bars"></i>
                            </div>

                            <div class="menubar-main-container-box">
                                <div id="menubar-main-container">
                                    <div id="menubar-container">

                                        <div id="menu-text">
                                            <ul>
                                                <div id="ul-container-a">
                                                    <li id="menu-menu" class="list">
                                                        <div id="menu-option-a" class="menu-top" href="">
                                                            <p>MENU</p> <i id="fa-xmark" class="fa-solid fa-xmark"></i>
                                                        </div>
                                                    </li>
                                                </div>

                                                <div class="ul-container-b-main-box">

                                                    <div id="ul-container-b">

                                                        <li id="menu-home" class="list">
                                                            <div id="menu-option-b" class="menu-option menu-middle-group" href="">
                                                                <p>HOME</p> <i class="fa-solid fa-greater-than"></i>
                                                            </div>

                                                        </li>

                                                        <div class="menubar-home-slide-container">
                                                            <ul>
                                                                <div class="home-menu-option-box">
                                                                    <li id="menu-menu-home-list" class="list">
                                                                        <div id="home-option-box" class="home-option-top" href="">
                                                                            <div class="home-text-arrow">
                                                                                <p>
                                                                                    < </p>
                                                                                        <p>Home</p>
                                                                            </div>

                                                                            <i id="home-option-fa-xmark" class="fa-solid fa-xmark"></i>
                                                                        </div>
                                                                    </li>

                                                                </div>

                                                                <div class="home-btn-all-options-box">

                                                                    <li class="home-option-list-a list">Main Demo</li>
                                                                    <li class="home-option-list-b list">Simple Modern</li>
                                                                    <li class="home-option-list-c list">Home Decor</li>
                                                                    <li class="home-option-list-d list">Skin Care</li>
                                                                    <li class="home-option-list-e list">Mega Store</li>
                                                                    <li class="home-option-list-f list">Insta Fashion</li>
                                                                    <li class="home-option-list-g list">Gym Fitness</li>
                                                                    <li class="home-option-list-h list">Smart Digital</li>
                                                                    <li class="home-option-list-i list">Swimwear</li>
                                                                    <li class="home-option-list-j list">Organic Foods</li>
                                                                    <li class="list"> <u>View All Demo</u> </li>
                                                                </div>

                                                            </ul>
                                                        </div>

                                                        <li id="menu-shope" class="list">
                                                            <div id="menu-option-c" class="menu-option menu-middle-group" href="">
                                                                <p>SHOP</p> <i class="fa-solid fa-greater-than"></i>
                                                            </div>
                                                        </li>

                                                        <div class="menubar-shope-slide-container">
                                                            <ul>
                                                                <div class="home-menu-option-box">
                                                                    <li id="menu-menu-home-list" class="list">
                                                                        <div id="home-option-box" class="home-option-top" href="">
                                                                            <div class="shop-text-arrow">
                                                                                <p>
                                                                                    < </p>
                                                                                        <p>Shop</p>
                                                                            </div>

                                                                            <i id="shop-option-fa-xmark" class="fa-solid fa-xmark"></i>
                                                                        </div>
                                                                    </li>

                                                                </div>

                                                                <div class="home-btn-all-options-box">

                                                                    <li class="shop-option-list-a list list-arrow">
                                                                        <p>Shop Layout</p>
                                                                        <p>></p>
                                                                    </li>
                                                                    <li class="shop-option-list-b list list-arrow">
                                                                        <p>Shop Page</p>
                                                                        <p>></p>
                                                                    </li>

                                                                </div>

                                                            </ul>
                                                        </div>

                                                        <li id="menu-product" class="list">
                                                            <div id="menu-option-d" class="menu-option menu-middle-group" href="">
                                                                <p>PRODUCT</p> <i class="fa-solid fa-greater-than"></i>
                                                            </div>
                                                        </li>

                                                        <div class="menubar-product-slide-container">
                                                            <ul>
                                                                <div class="home-menu-option-box">
                                                                    <li id="menu-menu-home-list" class="list">
                                                                        <div id="home-option-box" class="home-option-top" href="">
                                                                            <div class="product-text-arrow">
                                                                                <p>
                                                                                    < </p>
                                                                                        <p>Product</p>
                                                                            </div>

                                                                            <i id="product-option-fa-xmark" class="fa-solid fa-xmark"></i>
                                                                        </div>
                                                                    </li>

                                                                </div>

                                                                <div class="home-btn-all-options-box">

                                                                    <li class="product-option-list-a list list-arrow">
                                                                        <p>Product Layout</p>
                                                                        <p>></p>
                                                                    </li>
                                                                    <li class="product-option-list-b list list-arrow">
                                                                        <p>Product Features</p>
                                                                        <p>></p>
                                                                    </li>
                                                                    <li class="product-option-list-c list list-arrow">
                                                                        <p>Product Detail</p>
                                                                        <p>></p>
                                                                    </li>
                                                                    <li class="product-option-list-d list list-arrow">
                                                                        <p>Thumbnail Position</p>
                                                                        <p>></p>
                                                                    </li>
                                                                    <li class="product-option-list-e list list-arrow">
                                                                        <p>Boot Sale</p>
                                                                        <p>></p>
                                                                    </li>
                                                                    <li class="product-option-list-f list list-arrow">
                                                                        <p>Product Types</p>
                                                                        <p>></p>
                                                                    </li>


                                                                </div>

                                                            </ul>
                                                        </div>

                                                        <li id="menu-blog" class="list">
                                                            <div id="menu-option-e" class="menu-option menu-middle-group" href="">
                                                                <p>BLOG</p> <i class="fa-solid fa-greater-than"></i>
                                                            </div>
                                                        </li>

                                                        <div class="menubar-blog-slide-container">
                                                            <ul>
                                                                <div class="home-menu-option-box">
                                                                    <li id="menu-menu-home-list" class="list">
                                                                        <div id="home-option-box" class="home-option-top" href="">
                                                                            <div class="blog-text-arrow">
                                                                                <p>
                                                                                    < </p>
                                                                                        <p>Blog</p>
                                                                            </div>

                                                                            <i id="blog-option-fa-xmark" class="fa-solid fa-xmark"></i>
                                                                        </div>
                                                                    </li>

                                                                </div>

                                                                <div class="home-btn-all-options-box">

                                                                    <li class="blog-option-list-a list">Grid 2 columns</li>
                                                                    <li class="blog-option-list-b list">Grid 3 columns</li>
                                                                    <li class="blog-option-list-c list">Grid 4 columns</li>
                                                                    <li class="blog-option-list-d list">Post left sidebar</li>
                                                                    <li class="blog-option-list-e list">Post right sidebar</li>
                                                                    <li class="blog-option-list-f list">Post list view</li>
                                                                    <li class="blog-option-list-g list">Single post</li>
                                                                    <li class="blog-option-list-h list">Pagination loadmore</li>
                                                                    <li class="blog-option-list-i list">Pagination infinite scrolling</li>
                                                                </div>

                                                            </ul>
                                                        </div>

                                                        <li id="menu-page" class="list">
                                                            <div id="menu-option-f" class="menu-option menu-middle-group" href="">
                                                                <p>PAGE</p> <i class="fa-solid fa-greater-than"></i>
                                                            </div>
                                                        </li>

                                                        <div class="menubar-page-slide-container">
                                                            <ul>
                                                                <div class="home-menu-option-box">
                                                                    <li id="menu-menu-home-list" class="list">
                                                                        <div id="home-option-box" class="home-option-top" href="">
                                                                            <div class="page-text-arrow">
                                                                                <p>
                                                                                    < </p>
                                                                                        <p>Page</p>
                                                                            </div>

                                                                            <i id="page-option-fa-xmark" class="fa-solid fa-xmark"></i>
                                                                        </div>
                                                                    </li>

                                                                </div>

                                                                <div class="home-btn-all-options-box">

                                                                    <li class="page-option-list-a list">About us</li>
                                                                    <li class="page-option-list-b list">Our Store</li>
                                                                    <li class="page-option-list-c list">Faq's</li>
                                                                    <li class="page-option-list-d list">Brands</li>
                                                                    <li class="page-option-list-e list">Career</li>
                                                                    <li class="page-option-list-f list">Contact us</li>
                                                                    <li class="page-option-list-g list">Store location</li>
                                                                    <li class="page-option-list-h list">Timeline</li>
                                                                    <li class="page-option-list-i list">Portfolio</li>
                                                                    <li class="page-option-list-j list">Compare</li>
                                                                    <li class="page-option-list-j list">My account</li>
                                                                    <li class="page-option-list-j list">Page 404</li>
                                                                    <li class="page-option-list-j list">Recently Viewed Products</li>

                                                                </div>

                                                            </ul>
                                                        </div>

                                                        <li id="menu-sale" class="list">
                                                            <div id="menu-option-g" class="menu-option menu-middle-group" href="">
                                                                <p>SALE</p>
                                                            </div>
                                                        </li>

                                                        <li id="menu-buyumino" class="list">
                                                            <div id="menu-option-h" class="menu-option menu-middle-group" href="">
                                                                <p>BUY SKY!</p>
                                                            </div>
                                                        </li>

                                                        <!--  -->
                                                        <!--  -->

                                                        <li id="menu-buyumino" class="list">
                                                            <div id="menu-option-h" class="menu-option-recent-viewed menu-middle-group" onclick="window.location.href='sky9EcommerceResentViewedProd.php'">
                                                                <i class="fa-regular fa-clock"></i>
                                                                <p>RECENTLY VIEWED</p>
                                                            </div>
                                                        </li>

                                                        <li id="menu-buyumino" class="list">
                                                            <div id="menu-option-h" class="menu-option-wishlist menu-middle-group" onclick="window.location.href='sky9EcommerceWishlist.php'">
                                                                <i class="fa-regular fa-heart menu-page-icons"></i>
                                                                <p>WISHLIST</p>
                                                            </div>
                                                        </li>

                                                    </div>

                                                    <div id="menubtn-container">
                                                        <input id="menu-login-btn" type="button" value="LOG IN">
                                                        <input id="menu-acount-btn" type="button" value="CREATE ACOUNT">
                                                    </div>
                                                </div>

                                            </ul>
                                        </div>

                                    </div>
                                </div>
                            </div>

                        </div>


                        <div id="desktop-logo-box">
                            <h1 id="desktop-logo">SKY</h1>
                        </div>

                        <div id="desktop-icon-box">

                            <div class="desktop-search-box">
                                <i id="desktop-search-icon" class="fa-solid fa-magnifying-glass menu-page-icons"></i>


                                <div class="desktop-search-dropdown-main-con">

                                    <div class="desktop-search-dropdown">
                                        <div class="desktop-search-mainBox">


                                            <div class="desktop-search-input-box">
                                                <p class="desktop-search-text">Search Our Site</p>

                                                <p id="desktop-search-dropdown-xmark">
                                                    <i id="desktop-search-dropdown-fa-xmark" class="fa-solid fa-xmark"></i>
                                                </p>

                                                <div class="search-input-box">
                                                    <input class="desktop-search-input" type="text" placeholder="I'm looking for...">
                                                    <i class="fa-solid fa-magnifying-glass desktop-search-icon"></i>

                                                </div>
                                                <p class="paragraph">Quick Search: Cloths, One Piece</p>
                                            </div>


                                            <div class="desktop-search-img-box">
                                                <div class="desktop-search-img-text">
                                                    <p class="popular-product-text">Popular Products</p>
                                                </div>



                                                <div class="desktop-search-img-container">


                                                    <div id="desktop-search-img-main-a" class="desktop-search-img-main">
                                                        <div class="desktop-search-img">
                                                            <img class="desktop-popular-img" src="Ecommerce\DPimg-1.jpg" alt="">

                                                        </div>

                                                        <p class="cloth-title">Sky Stylish T-Shirt <br>Top</p>
                                                        <p class="cloth-price">$150.00 &nbsp<span><strike class="strike-price">$190.00</strike></span></p>
                                                        <div class="dropdown-cloth-color-selector-box">

                                                            <div class="dropdown-cloth-border">
                                                                <div class="select-cloth-color-a select-cloth-color">
                                                                </div>
                                                            </div>

                                                            <div class="dropdown-cloth-border">
                                                                <div class="select-cloth-color-b select-cloth-color">
                                                                </div>
                                                            </div>

                                                            <div class="dropdown-cloth-border">
                                                                <div class="select-cloth-color-c select-cloth-color">
                                                                </div>
                                                            </div>

                                                        </div>
                                                    </div>

                                                    <div id="desktop-search-img-main-b" class="desktop-search-img-main">
                                                        <div class="desktop-search-img">
                                                            <img class="desktop-popular-img" src="Ecommerce\DPimg-2.jpg" alt="">
                                                        </div>

                                                        <p class="cloth-title">Sky Stylish T-Shirt <br>Top</p>
                                                        <p class="cloth-priceB">$150.00 &nbsp</p>
                                                        <div class="dropdown-cloth-color-selector-box">

                                                            <div class="dropdown-cloth-border">
                                                                <div class="select-cloth-color-a select-cloth-color">
                                                                </div>
                                                            </div>

                                                            <div class="dropdown-cloth-border">
                                                                <div class="select-cloth-color-b select-cloth-color">
                                                                </div>
                                                            </div>

                                                            <div class="dropdown-cloth-border">
                                                                <div class="select-cloth-color-c select-cloth-color">
                                                                </div>
                                                            </div>

                                                        </div>
                                                    </div>

                                                    <div id="desktop-search-img-main-c" class="desktop-search-img-main">
                                                        <div class="desktop-search-img">
                                                            <img class="desktop-popular-img" src="Ecommerce/DPimg-3.jpg" alt="">
                                                        </div>

                                                        <p class="cloth-title">Sky Stylish T-Shirt <br>Top</p>
                                                        <p class="cloth-price">$150.00 &nbsp<span><strike class="strike-price">$190.00</strike></span></p>
                                                        <div class="dropdown-cloth-color-selector-box">

                                                            <div class="dropdown-cloth-border">
                                                                <div class="select-cloth-color-a select-cloth-color">
                                                                </div>
                                                            </div>

                                                            <div class="dropdown-cloth-border">
                                                                <div class="select-cloth-color-b select-cloth-color">
                                                                </div>
                                                            </div>

                                                            <div class="dropdown-cloth-border">
                                                                <div class="select-cloth-color-c select-cloth-color">
                                                                </div>
                                                            </div>

                                                        </div>
                                                    </div>

                                                    <div id="desktop-search-img-main-d" class="desktop-search-img-main">
                                                        <div class="desktop-search-img">
                                                            <img class="desktop-popular-img" src="Ecommerce/DPimg-4.jpg" alt="">
                                                        </div>

                                                        <p class="cloth-title">Sky Stylish T-Shirt <br>Top</p>
                                                        <p class="cloth-priceB">$150.00 &nbsp</p>
                                                        <div class="dropdown-cloth-color-selector-box">

                                                            <div class="dropdown-cloth-border">
                                                                <div class="select-cloth-color-a select-cloth-color">
                                                                </div>
                                                            </div>

                                                            <div class="dropdown-cloth-border">
                                                                <div class="select-cloth-color-b select-cloth-color">
                                                                </div>
                                                            </div>

                                                            <div class="dropdown-cloth-border">
                                                                <div class="select-cloth-color-c select-cloth-color">
                                                                </div>
                                                            </div>

                                                        </div>
                                                    </div>

                                                    <div id="desktop-search-img-main-e" class="desktop-search-img-main">
                                                        <div class="desktop-search-img">
                                                            <img class="desktop-popular-img" src="Ecommerce/DPimg-5.jpg" alt="">
                                                        </div>

                                                        <p class="cloth-title">Sky Stylish T-Shirt <br>Top</p>
                                                        <p class="cloth-price">$150.00 &nbsp<span><strike class="strike-price">$190.00</strike></span></p>
                                                        <div class="dropdown-cloth-color-selector-box">

                                                            <div class="dropdown-cloth-border">
                                                                <div class="select-cloth-color-a select-cloth-color">
                                                                </div>
                                                            </div>

                                                            <div class="dropdown-cloth-border">
                                                                <div class="select-cloth-color-b select-cloth-color">
                                                                </div>
                                                            </div>

                                                            <div class="dropdown-cloth-border">
                                                                <div class="select-cloth-color-c select-cloth-color">
                                                                </div>
                                                            </div>

                                                        </div>
                                                    </div>

                                                    <div id="desktop-search-img-main-f" class="desktop-search-img-main">
                                                        <div class="desktop-search-img">
                                                            <img class="desktop-popular-img" src="Ecommerce/DPimg-6.jpg" alt="">
                                                        </div>

                                                        <p class="cloth-title">Sky Stylish T-Shirt <br>Top</p>
                                                        <p class="cloth-price">$150.00 &nbsp<span><strike class="strike-price">$190.00</strike></span></p>
                                                        <div class="dropdown-cloth-color-selector-box">

                                                            <div class="dropdown-cloth-border">
                                                                <div class="select-cloth-color-a select-cloth-color">
                                                                </div>
                                                            </div>

                                                            <div class="dropdown-cloth-border">
                                                                <div class="select-cloth-color-b select-cloth-color">
                                                                </div>
                                                            </div>

                                                            <div class="dropdown-cloth-border">
                                                                <div class="select-cloth-color-c select-cloth-color">
                                                                </div>
                                                            </div>

                                                        </div>
                                                    </div>



                                                </div>



                                            </div>

                                        </div>
                                    </div>

                                </div>


                            </div>

                            <div class="desktop-user-box">
                                <i id="desktop-user-icon" class="fa-regular fa-user menu-page-icons"></i>


                                <div class="desktop-user-dropdown">

                                    <div class="desktop-user-mainBox">
                                        <form class="desktop-login-form" action="">
                                            <h2 class="desktop-login">Login</h2>
                                            <p id="desktop-user-dropdown-xmark"><i id="desktop-user-dropdown-fa-xmark" class="fa-solid fa-xmark"></i></p>




                                            <div class="desktop-EmailPass-box">
                                                <input class="desktop-email-input" type="text" placeholder="Your email*">
                                                <input class="desktop-password-input" type="text" placeholder="Password*">
                                            </div>

                                            <div class="forgot-password-box">
                                                <p class="forgot-password-text paragraph">Forgot your password?</p>
                                            </div>

                                            <div class="desktop-LoginAccount-box">
                                                <input class="desktop-login-btn" type="button" value="LOGIN">
                                                <input class="desktop-account-btn" type="submit" value="CREATE ACCOUNT">
                                            </div>




                                        </form>
                                    </div>
                                </div>


                            </div>

                            <div class="desktop-clock-box">
                                <a class="desktop-clock-link" href="sky9EcommerceResentViewedProd.php"><i class="fa-regular fa-clock menu-page-icons"></i></a>


                            </div>

                            <div class="desktop-heart-box">
                                <a class="desktop-heart-link" href="sky9EcommerceWishlist.php"><i class="fa-regular fa-heart menu-page-icons"></i></a>
                            </div>

                            <div class="desktop-cart-box">
                                <i class="fa-solid fa-cart-shopping menu-page-icons desktop-cart-icon"></i>

                                <div class="cart-main-background">

                                    <div class="desktop-cart-slide-con">
                                        <!-- <div class="desktop-cart-box"> -->
                                        <div class="cart-box">
                                            <div class="cart-box-a">

                                                <div class="cart-box-text">
                                                    <p class="shipping-heading">Shopping Cart <span>(0)</span></p>
                                                    <i id="cart-x-mark" class="fa-solid fa-xmark cart-x-mark"></i>

                                                </div>

                                                <div class="shipping-box">

                                                    <div class="shipping-car-box">
                                                        <div class="car-side-box">
                                                            <i class="fa-solid fa-car-side"></i>
                                                        </div>
                                                        <div class="cart-shipping"></div>
                                                    </div>

                                                    <p class="shipping-textA">Spend $100.00 more to enjoy <span class="shipping-textB">FREE SHIPPING!</span></p>
                                                </div>
                                            </div>

                                            <div class="cart-box-b">

                                                <div class="empty-cart-main-box">
                                                    <div class="empty-cart-box">
                                                        <i class="fa-regular fa-face-frown empty-cart-face"></i>

                                                        <p class="empty-face-text">Your cart is empty.</p>
                                                    </div>

                                                    <div class="empty-cart-text">
                                                        <p class="paragraph">You may check out all the available
                                                            products and buy some in the shop.</p>
                                                    </div>

                                                    <button class="empty-cart-btn"><a class="empty-cart-btn-link" href="">RETURN TO SHOP</a></button>
                                                </div>
                                            </div>


                                        </div>
                                        <!-- </div> -->
                                    </div>
                                </div>

                            </div>

                        </div>

                    </div>

                    <!-- desktop-header-textContainer -->
                    <div id="desktop-header-textContainer">
                        <div id="header-text-container-home" class="header-text-container">
                            <h6 class="header-menu-text" id="header-menu-text-home">HOME</h6>
                            <i id="home-downIcon" class="fa-solid fa-chevron-down downIcon"></i>
                        </div>

                        <div class="home-dropdown-container">
                            <div class="dropdown-img-box">

                                <div class="dropdown-img-con">
                                    <div class="dropdown-img-back">
                                        <img class="dropdown-img" src="Ecommerce\dropdown-1.jpg" alt="">
                                    </div>
                                    <div class="dropdown-text">
                                        <h6>Main Demo</h6>
                                    </div>
                                </div>

                                <div class="dropdown-img-con">
                                    <div class="dropdown-img-back">
                                        <img class="dropdown-img" src="Ecommerce\dropdown-2.jpg" alt="">
                                    </div>
                                    <div class="dropdown-text">
                                        <h6>Simple Modern</h6>
                                    </div>
                                </div>

                                <div class="dropdown-img-con">
                                    <div class="dropdown-img-back">
                                        <img class="dropdown-img" src="Ecommerce\dropdown-3.jpg" alt="">
                                    </div>
                                    <div class="dropdown-text">
                                        <h6>Home Decor</h6>
                                    </div>
                                </div>

                                <div class="dropdown-img-con">
                                    <div class="dropdown-img-back">
                                        <img class="dropdown-img" src="Ecommerce\dropdown-4.jpg" alt="">
                                    </div>
                                    <div class="dropdown-text">
                                        <h6>Skin Care</h6>
                                    </div>
                                </div>

                                <div class="dropdown-img-con">
                                    <div class="dropdown-img-back">
                                        <img class="dropdown-img" src="Ecommerce\dropdown-5.jpg" alt="">
                                    </div>
                                    <div class="dropdown-text">
                                        <h6>Mega Store</h6>
                                    </div>
                                </div>

                            </div>

                            <!--  -->

                            <div class="dropdown-img-box">

                                <div class="dropdown-img-con">
                                    <div class="dropdown-img-back">
                                        <img class="dropdown-img" src="Ecommerce\dropdown-6.jpg" alt="">
                                    </div>
                                    <div class="dropdown-text">
                                        <h6>Instagram Fashion</h6>
                                    </div>
                                </div>

                                <div class="dropdown-img-con">
                                    <div class="dropdown-img-back">
                                        <img class="dropdown-img" src="Ecommerce\dropdown-7.jpg" alt="">
                                    </div>
                                    <div class="dropdown-text">
                                        <h6>Gym Fitness</h6>
                                    </div>
                                </div>

                                <div class="dropdown-img-con">
                                    <div class="dropdown-img-back">
                                        <img class="dropdown-img" src="Ecommerce\dropdown-8.jpg" alt="">
                                    </div>
                                    <div class="dropdown-text">
                                        <h6>Smart Digital</h6>
                                    </div>
                                </div>

                                <div class="dropdown-img-con">
                                    <div class="dropdown-img-back">
                                        <img class="dropdown-img" src="Ecommerce\dropdown-9.jpg" alt="">
                                    </div>
                                    <div class="dropdown-text">
                                        <h6>Swimwear</h6>
                                    </div>
                                </div>

                                <div class="dropdown-img-con">
                                    <div class="dropdown-img-back">
                                        <img class="dropdown-img" src="Ecommerce\dropdown-10.jpg" alt="">
                                    </div>
                                    <div class="dropdown-text">
                                        <h6>Organic Food</h6>
                                    </div>
                                </div>

                            </div>

                            <div class="dropdown-demo-btn-container">
                                <button class="dropdown-demo-btn">View All Demos</button>
                            </div>



                        </div>


                        <div id="header-text-container-shop" class="header-text-container">
                            <h6 class="header-menu-text" id="header-menu-text-shop">SHOPE</h6>
                            <i id="shop-downIcon" class="fa-solid fa-chevron-down downIcon"></i>
                        </div>


                        <div class="shop-dropdown-container">

                            <div class="shop-column" id="shop-column-a">
                                <ul>
                                    <li class="shop-dropdown-heading">Product Layout</li>
                                    <li class="shop-dropdown-text"><a class="paragraph" href="">Default layout</a></li>
                                    <li class="shop-dropdown-text"><a class="paragraph" href="">nemo mollitia</a></li>
                                    <li class="shop-dropdown-text"><a class="paragraph" href="">dolor sit</a></li>
                                    <li class="shop-dropdown-text"><a class="paragraph" href="">mollitia</a></li>
                                    <li class="shop-dropdown-text"><a class="paragraph" href="">repudiandae</a></li>
                                    <li class="shop-dropdown-text"><a class="paragraph" href="">laborum excepturi</a>
                                    </li>
                                    <li class="shop-dropdown-text"><a class="paragraph" href="">adipisicing</a></li>

                                </ul>
                            </div>

                            <div class="shop-column" id="shop-column-b">

                                <ul>
                                    <li class="shop-dropdown-heading">Product Features</li>
                                    <li class="shop-dropdown-text"><a class="paragraph" href="">Compare color</a></li>
                                    <li class="shop-dropdown-text"><a class="paragraph" href="">repudiandae</a></li>
                                    <li class="shop-dropdown-text"><a class="paragraph" href="">nemo mollitia</a></li>
                                    <li class="shop-dropdown-text"><a class="paragraph" href="">excepturi</a></li>
                                    <li class="shop-dropdown-text"><a class="paragraph" href="">cum laborum</a></li>

                                </ul>

                            </div>

                            <div class="shop-img-column" id="shop-column-c">
                                <div class="shop-dropdown-img-box">
                                    <img class="shop-dropdown-img" src="Ecommerce\shopDrop-1.jpg" alt="">
                                    <div class="shop-dropdown-btn-box">
                                        <div class="shop-dropdown-btn-box-b">
                                            <a class="shop-dropdown-btn" href="">T-Shirt</a>
                                        </div>
                                    </div>
                                </div>

                                <div class="shop-dropdown-img-box">
                                    <img class="shop-dropdown-img" src="Ecommerce\shopDrop-2.jpg" alt="">
                                    <div class="shop-dropdown-btn-box">
                                        <div class="shop-dropdown-btn-box-b">
                                            <a class="shop-dropdown-btn" href="">Swim Bottom</a>
                                        </div>
                                    </div>

                                </div>

                            </div>

                        </div>


                        <div id="header-text-container-product" class="header-text-container">
                            <h6 class="header-menu-text" id="header-menu-text-product">PRODUCT</h6>
                            <i id="product-downIcon" class="fa-solid fa-chevron-down downIcon"></i>
                        </div>



                        <div class="product-dropdown-container">

                            <div class="product-column" id="product-column-a">
                                <ul>
                                    <li class="product-heading">Product Layout</li>
                                    <li class="product-text"><a class="paragraph" href="">Default layout</a></li>
                                    <li class="product-text"><a class="paragraph" href="">nemo mollitia</a></li>
                                    <li class="product-text"><a class="paragraph" href="">dolor sit</a></li>
                                    <li class="product-text"><a class="paragraph" href="">mollitia</a></li>
                                    <li class="product-text"><a class="paragraph" href="">repudiandae</a></li>
                                    <li class="product-text"><a class="paragraph" href="">laborum excepturi</a></li>
                                    <li class="product-text"><a class="paragraph" href="">adipisicing</a></li>
                                    <li class="product-text"><a class="paragraph" href="">sit amet</a></li>

                                </ul>
                            </div>



                            <div class="product-column" id="product-column-b">
                                <ul>
                                    <li class="product-heading">Product Features</li>
                                    <li class="product-text"><a class="paragraph" href="">Compare color</a></li>
                                    <li class="product-text"><a class="paragraph" href="">repudiandae</a></li>
                                    <li class="product-text"><a class="paragraph" href="">nemo mollitia</a></li>
                                    <li class="product-text"><a class="paragraph" href="">excepturi</a></li>
                                    <li class="product-text"><a class="paragraph" href="">cum laborum</a></li>
                                    <li class="product-text"><a class="paragraph" href="">culpa cum</a></li>
                                    <li class="product-text"><a class="paragraph" href="">obcaecati illum</a></li>
                                    <li class="product-text"><a class="paragraph" href="">ipsum dolor</a></li>
                                    <li class="product-text"><a class="paragraph" href="">adipisicing eli</a></li>

                                </ul>
                            </div>


                            <div class="product-column" id="product-column-c">
                                <ul>
                                    <li class="product-heading">Product Details</li>
                                    <li class="product-text"><a class="paragraph" href="">Real time visitor</a></li>
                                    <li class="product-text"><a class="paragraph" href="">repudiandae animi</a></li>
                                    <li class="product-text"><a class="paragraph" href="">mollitia</a></li>
                                    <li class="product-text"><a class="paragraph" href="">perferendis</a></li>
                                    <li class="product-text"><a class="paragraph" href="">perferendis</a></li>
                                    <li class="product-text"><a class="paragraph" href="">consectetur</a></li>
                                    <li class="product-text"><a class="paragraph" href="">sit amet</a></li>
                                    <li class="product-text"><a class="paragraph" href="">dolor sit</a></li>
                                    <li class="product-text"><a class="paragraph" href="">ipsum dolor</a></li>

                                </ul>
                            </div>

                            <div class="product-column" id="product-column-d">
                                <ul>
                                    <li class="product-heading">Thumbnails Position</li>
                                    <li class="product-text"><a class="paragraph" href="">Thumbnails left</a></li>
                                    <li class="product-text"><a class="paragraph" href="">adipisicing</a></li>
                                    <li class="product-text"><a class="paragraph" href="">Lorem ipsum dolor</a></li>
                                    <li class="product-text"><a class="paragraph" href="">Quo ipsa</a></li>
                                    <li class="product-text"><a class="paragraph" href="">nulla illum</a></li>
                                    <li class="product-text"><a class="paragraph" href="">Quo ipsa</a></li>
                                    <li class="product-text"><a class="paragraph" href="">sunt, fugit</a></li>
                                    <li class="product-text"><a class="paragraph" href="">perferendis</a></li>
                                    <li class="product-text"><a class="paragraph" href="">fugit cum</a></li>
                                    <li class="product-text"><a class="paragraph" href="">repudiandae animi</a></li>

                                </ul>
                            </div>

                            <div class="product-column" id="product-column-e">
                                <ul>
                                    <li class="product-heading">Boot Sale</li>
                                    <li class="product-text"><a class="paragraph" href="">Countdown timers</a></li>
                                    <li class="product-text"><a class="paragraph" href="">sit amet</a></li>
                                    <li class="product-text"><a class="paragraph" href="">nemo mollitia</a></li>
                                    <li class="product-text"><a class="paragraph" href="">repudiandae</a></li>
                                    <li class="product-text"><a class="paragraph" href="">voluptate sunt</a></li>
                                    <li class="product-text"><a class="paragraph" href="">perferendis</a></li>
                                    <li class="product-text"><a class="paragraph" href="">Quo ipsa</a></li>
                                    <li class="product-text"><a class="paragraph" href="">mollitia</a></li>
                                </ul>
                            </div>


                            <div class="product-column" id="product-column-f">
                                <ul>
                                    <li class="product-heading">Product Types</li>
                                    <li class="product-text"><a class="paragraph" href="">Simple product</a></li>
                                    <li class="product-text"><a class="paragraph" href="">nemo mollitia</a></li>
                                    <li class="product-text"><a class="paragraph" href="">repudiandae</a></li>
                                    <li class="product-text"><a class="paragraph" href="">excepturi</a></li>
                                    <li class="product-text"><a class="paragraph" href="">cum laboru</a></li>
                                    <li class="product-text"><a class="paragraph" href="">illum culpa</a></li>
                                    <li class="product-text"><a class="paragraph" href="">dolor sit</a></li>
                                </ul>
                            </div>

                        </div>


                        <div id="header-text-container-blog" class="header-text-container">
                            <h6 class="header-menu-text" id="gg">BlOG</h6>
                            <i class="fa-solid fa-chevron-down downIcon"></i>
                        </div>

                        <div class="blog-dropdown-container">

                            <div class="blog-text-container">
                                <ul>
                                    <li class="blog-dropdown-text"><a class="paragraph" href="">Grid 2 columns</a></li>
                                    <li class="blog-dropdown-text"><a class="paragraph" href="">Grid 3 columns</a></li>
                                    <li class="blog-dropdown-text"><a class="paragraph" href="">Grid 4 columns</a></li>
                                    <li class="blog-dropdown-text"><a class="paragraph" href="">Post left sidebar</a>
                                    </li>
                                    <li class="blog-dropdown-text"><a class="paragraph" href="">Post right sidebar</a>
                                    </li>
                                    <li class="blog-dropdown-text"><a class="paragraph" href="">Post list view</a></li>
                                    <li class="blog-dropdown-text"><a class="paragraph" href="">Single post</a></li>
                                    <li class="blog-dropdown-text"><a class="paragraph" href="">Pagination load more</a>
                                    </li>
                                    <li class="blog-dropdown-text"><a class="paragraph" href="">Pagination infinite
                                            scrolling</a></li>

                                </ul>
                            </div>

                        </div>


                        <div id="header-text-container-page" class="header-text-container">
                            <h6 class="header-menu-text" id="gg">PAGE</h6>
                            <i class="fa-solid fa-chevron-down downIcon"></i>
                        </div>

                        <div class="page-dropdown-container">

                            <div class="page-text-container">
                                <ul>
                                    <li class="page-dropdown-text"><a class="paragraph" href="">About us</a></li>
                                    <li class="page-dropdown-text"><a class="paragraph" href="">Our Store</a></li>
                                    <li class="page-dropdown-text"><a class="paragraph" href="">Faq's</a></li>
                                    <li class="page-dropdown-text"><a class="paragraph" href="">Brand</a></li>
                                    <li class="page-dropdown-text"><a class="paragraph" href="">Career</a></li>
                                    <li class="page-dropdown-text"><a class="paragraph" href="">Contact us</a></li>
                                    <li class="page-dropdown-text"><a class="paragraph" href="">Store location</a></li>
                                    <li class="page-dropdown-text"><a class="paragraph" href="">Timeline</a></li>
                                    <li class="page-dropdown-text"><a class="paragraph" href="">Portfolio</a></li>
                                    <li class="page-dropdown-text"><a class="paragraph" href="">Compare</a></li>
                                    <li class="page-dropdown-text"><a class="paragraph" href="">My account</a></li>
                                    <li class="page-dropdown-text"><a class="paragraph" href="">Page 404</a></li>
                                    <li class="page-dropdown-text"><a class="paragraph" href="">Recently Viewed
                                            Products</a></li>

                                </ul>
                            </div>

                        </div>



                        <div id="header-text-container-sale" class="header-text-container">
                            <h6 class="header-menu-text" id="gg">SALE</h6>
                        </div>
                        <div id="header-text-container-buySkyShop" class="header-text-container">
                            <h6 class="header-menu-text" id="gg">BUY SKY-SHOP!</h6>
                        </div>


                    </div>


                </div>
            </div>

            <!--5 popular-products-container -->
            <div class="wishlist-box">
                <div id="popular-products-container">
                    <div id="popular-products-text">
                        <p id="heading-text" class="heading">
                            Wishlist
                        </p>
                        <p id="paragraph-text" class="paragraph wishlist-paragraph-a">
                            Home / Wishlist
                        </p>

                        <div class="wishlist-paragraph-status-box">
                            <p id="paragraph-text" class="paragraph wishlist-paragraph-b">
                                No products were added to the wishlist page.  <a href="sky9EcommerceWebsite.php"><ins>Back to shopping</ins></a>
                            </p>

                            <!-- <button id="wishlist-btn">CLEAR ALL</button> -->
                        </div>
                    </div>

                </div>
            </div>

            <!--6 popular-product-img -->

            <div id="resent-viewed-product-img">

                <div id="product" class="carousel">


                    <!-- <div class="left" id="left-scroll">
                        <i class="fa-solid fa-less-than"></i>
                    </div>

                    <div id="product-main-container" class="card">

                        <div id="product-container">

                            <img id="product-img" class="item" src="Ecommerce/T-Sirt-3.webp" draggable="false" alt="product-img">
                            <div id="product-btn">
                                <button id="product-img-btn">
                                    <h6>ADD TO CART</h6>
                                </button>
                            </div>

                            <div id="popular-product-icons">
                                <div id="icon-container-a">
                                    <p class="popular-icon" id="popular-icon-a">
                                        <i class="fa-regular fa-heart"></i>
                                    </p>
                                </div>
                                <div id="wish-container">
                                    <h2 id="wishlist">Add to wishlist</h2>
                                </div>
                                <div id="icon-container-b">
                                    <p class="popular-icon" id="popular-icon-a"><i class="fa-solid fa-code-compare"></i></i>
                                    </p>
                                </div>
                                <div id="compare-container">
                                    <h2 id="compare">Compare</h2>
                                </div>
                                <div id="icon-container-c">
                                    <p class="popular-icon" id="popular-icon-a"><i class="fa-solid fa-eye"></i></p>
                                </div>
                                <div id="view-container">
                                    <h2 id="view">Quick view</h2>
                                </div>
                            </div>
                        </div>

                        <div class="product-details">

                            <p class="cloth-title">Stylish Black And Pink Shirt</p>
                            <p class="cloth-price">$150.00 &nbsp<span><strike class="strike-price">$190.00</strike></span></p>
                            <div class="dropdown-cloth-color-selector-box">

                                <div class="dropdown-cloth-border">
                                    <div class="select-cloth-color-a select-cloth-color"></div>
                                </div>

                                <div class="dropdown-cloth-border">
                                    <div class="select-cloth-color-b select-cloth-color"></div>
                                </div>

                                <div class="dropdown-cloth-border">
                                    <div class="select-cloth-color-c select-cloth-color"></div>
                                </div>

                            </div>

                        </div>

                    </div>

                    <div class="right" id="right-scroll">
                        <i class="fa-solid fa-greater-than"></i>
                    </div> -->

                </div>

            </div>

            <!--14 footer-main-container -->
            <div id="footer-main-container">
                <div id="footer-container">

                    <div id="footer">


                        <div id="column-a">
                            <div class="footer-heading-box-a">
                                <p id="footer-heading">Contact Us</p>
                                <i class="fa-solid fa-plus footer-heading-dropDown-a"></i>
                            </div>

                            <div class="footer-all-text-a">

                                <p id="footer-paragraph-a1" class="paragraph">268 St, South New York/NY 98944,
                                    United
                                    States.</p>
                                <p id="footer-paragraph-a2" class="paragraph">+222-1800-2628</p>
                                <p id="footer-paragraph-a3" class="paragraph">blueskytechcompany@gmail.com</p>

                                <div id="brand-icons">

                                    <div id="brand-icons-a"><i id="footer-brand-icons-a" class="fa-brands fa-twitter"></i>
                                        <p id="twitter" class="footer-brand-name">Twitter</p>
                                    </div>
                                    <div id="brand-icons-b"><i id="footer-brand-icons-b" class="fa-brands fa-facebook"></i>
                                        <p id="facebook" class="footer-brand-name">Facebook</p>
                                    </div>
                                    <div id="brand-icons-c"><i id="footer-brand-icons-c" class="fa-brands fa-pinterest"></i>
                                        <p id="pinterest" class="footer-brand-name">Pinterest</p>
                                    </div>
                                    <div id="brand-icons-d"><i id="footer-brand-icons-d" class="fa-brands fa-instagram"></i>
                                        <p id="instagram" class="footer-brand-name">Instagram</p>
                                    </div>
                                    <div id="brand-icons-e"><i id="footer-brand-icons-e" class="fa-brands fa-youtube"></i>
                                        <p id="youtube" class="footer-brand-name">YouTube</p>
                                    </div>
                                    <div id="brand-icons-f"><i id="footer-brand-icons-f" class="fa-brands fa-snapchat"></i>
                                        <p id="snapchat" class="footer-brand-name">Snapchat</p>
                                    </div>
                                    <div id="brand-icons-g"><i id="footer-brand-icons-g" class="fa-brands fa-linkedin"></i>
                                        <p id="linkedin" class="footer-brand-name">Linkedin</p>
                                    </div>

                                </div>
                            </div>

                        </div>

                        <div id="column-b">
                            <div class="footer-heading-box-b">
                                <p id="footer-heading">Hot Categories</p>
                                <i class="fa-solid fa-plus footer-heading-dropDown-b"></i>
                            </div>

                            <div class="footer-all-text-b">

                                <p id="footer-paragraph-b1" class="paragraph footer-paragraph">Special Offers</p>
                                <p id="footer-paragraph-b2" class="paragraph footer-paragraph">Performance</p>
                                <p id="footer-paragraph-b3" class="paragraph footer-paragraph">T-Shirts</p>
                                <p id="footer-paragraph-b4" class="paragraph footer-paragraph">Underwear</p>
                                <p id="footer-paragraph-b5" class="paragraph footer-paragraph">Top Brands</p>
                                <p id="footer-paragraph-b6" class="paragraph footer-paragraph">Online Exclusive</p>
                            </div>

                        </div>



                        <div id="column-c">
                            <div class="footer-heading-box-c">
                                <p id="footer-heading">Customer Service</p>
                                <i class="fa-solid fa-plus footer-heading-dropDown-c"></i>
                            </div>

                            <div class="footer-all-text-c">

                                <p id="footer-paragraph-c1" class="paragraph footer-paragraph">Privacy Policy</p>
                                <p id="footer-paragraph-c2" class="paragraph footer-paragraph">Refund Policy</p>
                                <p id="footer-paragraph-c3" class="paragraph footer-paragraph">Shipping & Return</p>
                                <p id="footer-paragraph-c4" class="paragraph footer-paragraph">Term & Conditions</p>
                                <p id="footer-paragraph-c5" class="paragraph footer-paragraph">Advanced Search</p>
                                <p id="footer-paragraph-c6" class="paragraph footer-paragraph">Theme FAQs</p>
                                <p id="footer-paragraph-c7" class="paragraph footer-paragraph">Store Locations</p>
                            </div>

                        </div>

                        <div id="column-d">
                            <div class="footer-heading-box-d">
                                <p id="footer-heading">Sign Up to Newsletter</p>
                                <i class="fa-solid fa-plus footer-heading-dropDown-d"></i>
                            </div>

                            <div class="footer-all-text-d">

                                <p id="footer-paragraph-d1" class="paragraph">Enter your email address to get $10
                                    off your
                                    first order and free shipping.Updates information on Sales and
                                    Offers.</p>

                                <div id="input-btn">
                                    <input id="footer-search-input" type="search" name="search" placeholder="Enter your email...">
                                    <input type="button" value="SUBSCRIBE" id="footer-input-btn">
                                </div>
                            </div>

                        </div>


                    </div>




                    <!-- bottom-futter-text-icon -->
                    <div id="bottom-futter-text-icon">
                        <div id="bottom-text">
                            <div id="selector">
                                <p id="language" class="paragraph">English </p>
                                <p id="country" class="paragraph">United States (USD $) </p>

                            </div>
                            <p id="brand-rights" class="paragraph">© 2022 Umino Store. All Rights Reserved</p>

                            <div id="bottom-img">
                                <img id="bottom-logo-img" src="Ecommerce\logo-paypal.png" alt="">
                                <img id="bottom-logo-img" src="Ecommerce\logo-coca-cola.png" alt="">
                                <img id="bottom-logo-img" src="Ecommerce\logo-godrej.png" alt="">
                                <img id="bottom-logo-img" src="Ecommerce\logo-oppo.png" alt="">
                                <img id="bottom-logo-img" src="Ecommerce\logo-philips.png" alt="">

                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <!--  -->
        </div>

        <!--  -->
    </div>


    

    <!--  -->

    <script src="sky9EcommerceWebsite.js"></script>

    <script type="text/javascript">
        let btnClickCheck = false;
        let ty=true;
        $(document).ready(function() {
            pageLoad('wishlistDataCheck')
        })

        function pageLoad(wishlistDataCheck, wishlistDelete) {
            // console.log(wishlistDelete);

            $.ajax({
                url: "sky9EcommerceWebsiteDB.php",
                type: "POST",
                dataType: "JSON",
                data: {
                    wishlistDataCheck: wishlistDataCheck,
                    wishlistDelete: wishlistDelete,
                },
                success: function(data) {
                    let wishlistData = "";
                    $.each(data, function(key, value) {
                        wishlistData += `<div id="product-main-container" class="card">

                        <div id="product-container">

                            <img id="product-img" class="item" src="${value.WishlistIMG}" draggable="false" alt="product-img">
                            <div id="product-btn">
                                <button id="product-img-btn">
                                    <h6>ADD TO CART</h6>
                                </button>
                            </div>


                            <div onclick="wishID('${value.ID}')" id="remove-icon-container">
                                <p class="popular-icon" id="popular-icon-a">
                                    <i class="fa-solid fa-xmark"></i>
                                </p>
                            </div>

                            <div id="remove-text-container">
                                <h2 id="wishlist">Remove from wishlist</h2>
                            </div>

                            <div id="popular-product-icons">
                                <div id="wish-remove-box">
                                </div>
                                
                                <div id="icon-container-b">
                                    <p class="popular-icon" id="popular-icon-a"><i class="fa-solid fa-code-compare"></i></i>
                                    </p>
                                </div>
                                <div id="compare-container">
                                    <h2 id="compare">Compare</h2>
                                </div>
                                <div id="icon-container-c">
                                    <p class="popular-icon" id="popular-icon-a"><i class="fa-solid fa-eye"></i></p>
                                </div>
                                <div id="view-container">
                                    <h2 id="view">Quick view</h2>
                                </div>
                            </div>
                        </div>

                        <div class="product-details">

                            <p class="cloth-title">Stylish Black And Pink Shirt</p>
                            <p class="cloth-price">$150.00 &nbsp<span><strike class="strike-price">$190.00</strike></span></p>
                            <div class="dropdown-cloth-color-selector-box">

                                <div class="dropdown-cloth-border">
                                    <div class="select-cloth-color-a select-cloth-color"></div>
                                </div>

                                <div class="dropdown-cloth-border">
                                    <div class="select-cloth-color-b select-cloth-color"></div>
                                </div>

                                <div class="dropdown-cloth-border">
                                    <div class="select-cloth-color-c select-cloth-color"></div>
                                </div>

                            </div>

                        </div>

                        </div>`;
                    });

                    $('#product').html("")
                    $('#product').append(wishlistData)


                    if (wishlistData == "") {
                        $('.wishlist-paragraph-b').css({
                            'display': 'block'
                        })
                    }else if(!wishlistData == ""){
                        $('.wishlist-paragraph-b').css({
                            'display': 'none'
                        })

                    }

                }

            })


        };

        function wishID(wishlistDelete){
            pageLoad('', wishlistDelete);
            console.log(wishlistDelete)
        }
    </script>

</body>

</html>


