<?php

// database connection
// $con = mysqli_connect("localhost", "root", "", "skyphp") or die("connection failed");
include 'sky9connect.php';

// home page top picks new arrivals
// top picks
if (isset($_POST['TopPickInfo']) && !empty($_POST['TopPickInfo'])) {

    // $sql = "SELECT * FROM `weballproducts`";
    $sql="SELECT * FROM `weballproducts` WHERE Product_Code='1'";

    $query = mysqli_query($con, $sql);

    $result = mysqli_fetch_all($query, MYSQLI_ASSOC);
    if (empty($result)) {
        $sql = 'TRUNCATE TABLE `weballproducts`';
        $query = mysqli_query($con, $sql);
    }
    echo json_encode($result);
    
}

// new arrivals
if (isset($_POST['NewArrivalsInfo']) && !empty($_POST['NewArrivalsInfo'])) {

    // $sql = "SELECT * FROM `weballproductsb`;
    $sql="SELECT * FROM `weballproducts` WHERE Product_Code='2'";
    $query = mysqli_query($con, $sql);

    $result = mysqli_fetch_all($query, MYSQLI_ASSOC);
    if (empty($result)) {
        $sql = 'TRUNCATE TABLE `weballproductsb`';
        $query = mysqli_query($con, $sql);
    }
    echo json_encode($result);
    
}


// recentViewImg
$resentViewDataCheck = false;
if (isset($_POST['resentViewDataCheck']) && !empty($_POST['resentViewDataCheck'])) {
    $resentViewDataCheck = true;
}

// recentViewImg
$wishlistDataCheck = false;
if (isset($_POST['wishlistDataCheck']) && !empty($_POST['wishlistDataCheck'])) {
    $wishlistDataCheck = true;
};


// check data is coming or not empty
// recentViewImg
if (isset($_POST['recentViewImg']) && !empty($_POST['recentViewImg'])) {

    $recentViewImg = $_POST['recentViewImg'];

    // check product already exist or not
    $sql2 = "SELECT * FROM `webrecentviewe` WHERE ResentViewIMG='$recentViewImg'";
    $query2 = mysqli_query($con, $sql2);
    $row = mysqli_fetch_array($query2);

    if (!$row) {                      //if data does'nt exist
        $sql3 = "INSERT INTO `webrecentviewe`(ResentViewIMG) VALUES('$recentViewImg')";
        $query3 = mysqli_query($con, $sql3);
    } else {                           //if data exists then delete the data and insert in the last

    };
}

// recentViewImg
if (isset($_POST['clear']) && !empty($_POST['clear'])) {
    $sql4 = 'TRUNCATE TABLE webrecentviewe';
    $query4 = mysqli_query($con, $sql4);

    $sql = "SELECT * FROM `webrecentviewe`";
    $query = mysqli_query($con, $sql);
    $result = mysqli_fetch_all($query, MYSQLI_ASSOC);
    echo json_encode($result);
} else {


    if ($resentViewDataCheck) {
        $sql = "SELECT * FROM `webrecentviewe`";
        $query = mysqli_query($con, $sql);
        $result = mysqli_fetch_all($query, MYSQLI_ASSOC);
        echo json_encode($result);
    }
}

// check data is coming or not empty
// wishlistImg
if (isset($_POST['wishlistImg']) && !empty($_POST['wishlistImg'])) {
    $wishlistImg = $_POST['wishlistImg'];

    // check product already exist or not
    $sql2 = "SELECT * FROM `webwishlist` WHERE WishlistIMG='$wishlistImg'";
    $query2 = mysqli_query($con, $sql2);
    $row = mysqli_fetch_array($query2);


    if (!$row) {                      //if data does'nt exist
        $sql3 = "INSERT INTO `webwishlist`(WishlistIMG) VALUES('$wishlistImg')";
        $query3 = mysqli_query($con, $sql3);
    } else {                           //if data exists then delete the data and insert in the last

    };
};

// wishlistImg

if (isset($_POST['wishlistDelete']) && !empty($_POST['wishlistDelete'])) {
    $wishlistDeleteData = true;
    $wishlistDelete = $_POST['wishlistDelete'];

    $sql = "DELETE FROM `webwishlist` WHERE ID=$wishlistDelete";
    $query = mysqli_query($con, $sql);

    $sql2 = "SELECT * FROM `webwishlist`";
    $query2 = mysqli_query($con, $sql2);
    $result = mysqli_fetch_all($query2, MYSQLI_ASSOC);
    if (empty($result)) {
        $sql3 = 'TRUNCATE TABLE webwishlist';
        $query3 = mysqli_query($con, $sql3);
    }
    echo json_encode($result);
} else {
    if ($wishlistDataCheck) {
        $sql = "SELECT * FROM `webwishlist`";
        $query = mysqli_query($con, $sql);
        $result = mysqli_fetch_all($query, MYSQLI_ASSOC);
        echo json_encode($result);
    }
}

// // // // //

// ProductDetailResentViewDataCheck

$ProductDetailResentViewDataCheck = false;
if (isset($_POST['ProductDetailResentViewDataCheck']) && !empty($_POST['ProductDetailResentViewDataCheck'])) {
    $ProductDetailResentViewDataCheck = true;
}

if (isset($_POST['ProductDetailResentViewDataCheck']) && !empty($_POST['ProductDetailResentViewDataCheck'])) {

    $ProductDetailResentViewDataCheck = $_POST['ProductDetailResentViewDataCheck'];
}

if($ProductDetailResentViewDataCheck){
    $sql = "SELECT * FROM `webrecentviewe`";
        $query = mysqli_query($con, $sql);
        $result = mysqli_fetch_all($query, MYSQLI_ASSOC);
        echo json_encode($result);
}

// product detail click IMG
// if (isset($_GET['CLICKID']) && !empty($_GET['CLICKID'])) {

//     $clickedImg = $_GET['CLICKID'];

//     session_start();
//     $_SESSION['ID'] = "";
//     $_SESSION['ID'] = $clickedImg;
//     // $sql = "SELECT * FROM `allproducts` WHERE ID='$clickedImg'";

//     // $query = mysqli_query($con, $sql) or die("connection nn");
//     // $result = mysqli_fetch_all($query, MYSQLI_ASSOC) or die("connection dd");
//     // echo json_encode($result);

//     header('location:sky9EcommerceWebsiteProductDetail.php');
// } 

if (isset($_GET['ClickIMG']) && !empty($_GET['ClickIMG']) && isset($_GET['tableCode']) && !empty($_GET['tableCode'])) {

    $clickedImg = $_GET['ClickIMG'];
    $tableCode = $_GET['tableCode'];


    session_start();
    $_SESSION['ID'] = "";
    $_SESSION['code'] = "";

    $_SESSION['ID'] = $clickedImg;
    $_SESSION['code'] = $tableCode;


    header('location:sky9EcommerceWebsiteProductDetail.php');
}



// product detail click IMG ID 

if (isset($_POST['ID']) && !empty($_POST['ID']) && isset($_POST['tableCode']) && !empty($_POST['tableCode'])) {

    $ID = $_POST['ID'];
    $tableCode=$_POST['tableCode'];

    if($tableCode<=1){

        $sql = "SELECT * FROM `weballproducts` WHERE ID=$ID";
        $query = mysqli_query($con, $sql) or die("connection nn");
        $result = mysqli_fetch_all($query, MYSQLI_ASSOC) or die("connection dd");
        echo json_encode($result);
    }elseif($tableCode>=2){
        $sql = "SELECT * FROM `weballproducts` WHERE ID=$ID";
        $query = mysqli_query($con, $sql) or die("connection nn");
        $result = mysqli_fetch_all($query, MYSQLI_ASSOC) or die("connection dd");
        echo json_encode($result);
    }
}
